<?php
ob_start();
session_start();
$con = mysql_connect("localhost","jasaprog_pos_bu_diana","L1nt4ngPOS");
mysql_select_db("jasaprog_pos_bu_diana", $con);
unset($_SESSION['menu_active']);
unset($_SESSION['sub_menu_active']);
?>
