
-- --------------------------------------------------------

--
-- Table structure for table `stock_retur_pembelian`
--

DROP TABLE IF EXISTS `stock_retur_pembelian`;
CREATE TABLE `stock_retur_pembelian` (
  `item_stock_retur_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `item_stock_qty` float NOT NULL,
  `branch_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `stock_retur_pembelian`
--

TRUNCATE TABLE `stock_retur_pembelian`;
--
-- Dumping data for table `stock_retur_pembelian`
--

INSERT INTO `stock_retur_pembelian` (`item_stock_retur_id`, `item_id`, `item_stock_qty`, `branch_id`) VALUES
(1, 2, 3, 3),
(2, 1, 1, 3);
