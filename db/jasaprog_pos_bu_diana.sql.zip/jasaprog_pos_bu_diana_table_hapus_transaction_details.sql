
-- --------------------------------------------------------

--
-- Table structure for table `hapus_transaction_details`
--

DROP TABLE IF EXISTS `hapus_transaction_details`;
CREATE TABLE `hapus_transaction_details` (
  `transaction_detail_id` int(11) NOT NULL,
  `transaction_id` int(11) NOT NULL,
  `item_type` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `transaction_detail_original_price` bigint(11) NOT NULL,
  `transaction_detail_margin_price` bigint(11) NOT NULL,
  `transaction_detail_price` bigint(11) NOT NULL,
  `transaction_detail_price_discount` bigint(11) NOT NULL,
  `transaction_detail_grand_price` bigint(11) NOT NULL,
  `transaction_detail_qty` float NOT NULL,
  `transaction_detail_unit` int(11) NOT NULL,
  `transaction_detail_total` int(11) NOT NULL,
  `retur` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `hapus_transaction_details`
--

TRUNCATE TABLE `hapus_transaction_details`;
--
-- Dumping data for table `hapus_transaction_details`
--

INSERT INTO `hapus_transaction_details` (`transaction_detail_id`, `transaction_id`, `item_type`, `item_id`, `transaction_detail_original_price`, `transaction_detail_margin_price`, `transaction_detail_price`, `transaction_detail_price_discount`, `transaction_detail_grand_price`, `transaction_detail_qty`, `transaction_detail_unit`, `transaction_detail_total`, `retur`) VALUES
(1, 2, 0, 1, 16000, 0, 16000, 0, 1936000, 121, 14, 1936000, 0);
