
-- --------------------------------------------------------

--
-- Table structure for table `items_types`
--

DROP TABLE IF EXISTS `items_types`;
CREATE TABLE `items_types` (
  `item_type_id` int(11) NOT NULL,
  `item_type_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `items_types`
--

TRUNCATE TABLE `items_types`;