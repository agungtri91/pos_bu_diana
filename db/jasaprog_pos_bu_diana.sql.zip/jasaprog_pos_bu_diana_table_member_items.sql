
-- --------------------------------------------------------

--
-- Table structure for table `member_items`
--

DROP TABLE IF EXISTS `member_items`;
CREATE TABLE `member_items` (
  `member_item_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `member_items`
--

TRUNCATE TABLE `member_items`;