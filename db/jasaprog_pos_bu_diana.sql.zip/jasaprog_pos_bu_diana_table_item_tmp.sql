
-- --------------------------------------------------------

--
-- Table structure for table `item_tmp`
--

DROP TABLE IF EXISTS `item_tmp`;
CREATE TABLE `item_tmp` (
  `id_item_tmp` int(11) NOT NULL,
  `item_types` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `harga` bigint(11) NOT NULL,
  `item_stock_qty` float NOT NULL,
  `harga_total` bigint(11) NOT NULL,
  `unit_id` bigint(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `purchases_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `item_tmp`
--

TRUNCATE TABLE `item_tmp`;
--
-- Dumping data for table `item_tmp`
--

INSERT INTO `item_tmp` (`id_item_tmp`, `item_types`, `item_id`, `harga`, `item_stock_qty`, `harga_total`, `unit_id`, `supplier_id`, `branch_id`, `purchases_id`) VALUES
(3, 0, 1, 2000000, 1, 2000000, 14, 0, 3, 10);
