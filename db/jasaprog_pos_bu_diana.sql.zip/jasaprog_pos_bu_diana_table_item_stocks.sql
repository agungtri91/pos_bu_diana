
-- --------------------------------------------------------

--
-- Table structure for table `item_stocks`
--

DROP TABLE IF EXISTS `item_stocks`;
CREATE TABLE `item_stocks` (
  `item_stock_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `item_type_id` int(11) NOT NULL,
  `item_stock_qty` float NOT NULL,
  `branch_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `item_stocks`
--

TRUNCATE TABLE `item_stocks`;
--
-- Dumping data for table `item_stocks`
--

INSERT INTO `item_stocks` (`item_stock_id`, `item_id`, `item_type_id`, `item_stock_qty`, `branch_id`) VALUES
(1, 1, 0, 1275, 3),
(2, 2, 0, 205, 3);
