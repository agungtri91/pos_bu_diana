
-- --------------------------------------------------------

--
-- Table structure for table `transactions_tmp`
--

DROP TABLE IF EXISTS `transactions_tmp`;
CREATE TABLE `transactions_tmp` (
  `transaction_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `transaction_date` datetime NOT NULL,
  `transaction_code` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `partner_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `transactions_tmp`
--

TRUNCATE TABLE `transactions_tmp`;