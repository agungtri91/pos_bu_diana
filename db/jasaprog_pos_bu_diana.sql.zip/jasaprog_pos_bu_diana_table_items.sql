
-- --------------------------------------------------------

--
-- Table structure for table `items`
--

DROP TABLE IF EXISTS `items`;
CREATE TABLE `items` (
  `item_id` int(11) NOT NULL,
  `item_type` int(11) NOT NULL,
  `kategori_id` int(11) NOT NULL,
  `sub_kategori_id` int(11) NOT NULL,
  `item_name` varchar(100) NOT NULL,
  `unit_id` int(11) NOT NULL,
  `item_limit` int(11) NOT NULL,
  `stock_img` text NOT NULL,
  `kode_barang` varchar(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `items`
--

TRUNCATE TABLE `items`;
--
-- Dumping data for table `items`
--

INSERT INTO `items` (`item_id`, `item_type`, `kategori_id`, `sub_kategori_id`, `item_name`, `unit_id`, `item_limit`, `stock_img`, `kode_barang`) VALUES
(1, 0, 6, 17, 'PHILLIPS 12 WATT', 14, 111, '1486366486_3b06f909-24f4-47ba-9206-2fbf5ae86570.jpg', '  214124'),
(2, 0, 6, 0, 'PHILLIPS 8 WATT', 20, 22, '1486366247_samsung-i9300l-galaxy-s3.jpg', '214124'),
(28, 0, 7, 20, 'Supra GTX', 14, 0, '1486397151_Review-Motor-Honda-Supra-GTR-150.jpg', '12343434'),
(29, 0, 0, 0, 'KIPAS ANGIN MASPION 	', 14, 0, '1486455352_kipas-angin-maspion-terbaru.png', '32434343'),
(31, 0, 0, 0, 'Kulkas Polytron', 14, 10, '1486478527_POLYTRON-Kulkas-1-Pintu-PRN-160B--SKU00816061-201621195456.jpg', '7765'),
(39, 0, 0, 0, 'HONDA CR-Z', 0, 0, 'MY16_CRZ_exterior_1.jpg', '4354353'),
(41, 0, 6, 17, 'Item Coba 1', 20, 2, '', '12345'),
(42, 0, 10, 0, 'PP 8 X 0.3', 0, 40, '', 'PP803'),
(43, 0, 7, 20, 'LAMPU PHILIPS 6 W', 0, 0, '', '');
