
-- --------------------------------------------------------

--
-- Table structure for table `hapus_purchase_details`
--

DROP TABLE IF EXISTS `hapus_purchase_details`;
CREATE TABLE `hapus_purchase_details` (
  `purchase_detail_id` int(11) NOT NULL,
  `purchase_id` int(11) NOT NULL,
  `purchase_date` date NOT NULL,
  `item_id` int(11) NOT NULL,
  `purchase_qty` float NOT NULL,
  `purchase_price` bigint(11) NOT NULL,
  `purchase_total` bigint(11) NOT NULL,
  `retur` float NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `hapus_purchase_details`
--

TRUNCATE TABLE `hapus_purchase_details`;
--
-- Dumping data for table `hapus_purchase_details`
--

INSERT INTO `hapus_purchase_details` (`purchase_detail_id`, `purchase_id`, `purchase_date`, `item_id`, `purchase_qty`, `purchase_price`, `purchase_total`, `retur`) VALUES
(9, 4, '2017-01-12', 1, 100, 10500, 1050000, 0);
