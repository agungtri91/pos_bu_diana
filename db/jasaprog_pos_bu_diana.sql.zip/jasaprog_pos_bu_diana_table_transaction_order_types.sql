
-- --------------------------------------------------------

--
-- Table structure for table `transaction_order_types`
--

DROP TABLE IF EXISTS `transaction_order_types`;
CREATE TABLE `transaction_order_types` (
  `tot_id` int(11) NOT NULL,
  `tot_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `transaction_order_types`
--

TRUNCATE TABLE `transaction_order_types`;