
-- --------------------------------------------------------

--
-- Table structure for table `retur_widget_details_tmp`
--

DROP TABLE IF EXISTS `retur_widget_details_tmp`;
CREATE TABLE `retur_widget_details_tmp` (
  `retur_widget_details_tmp_id` int(11) NOT NULL,
  `retur_tmp_id` int(11) NOT NULL,
  `transaction_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `kategori_keterangan_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `retur_widget_details_tmp`
--

TRUNCATE TABLE `retur_widget_details_tmp`;
--
-- Dumping data for table `retur_widget_details_tmp`
--

INSERT INTO `retur_widget_details_tmp` (`retur_widget_details_tmp_id`, `retur_tmp_id`, `transaction_id`, `item_id`, `kategori_keterangan_id`) VALUES
(14, 0, 0, 1, 0),
(15, 0, 0, 1, 0);
