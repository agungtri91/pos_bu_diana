
-- --------------------------------------------------------

--
-- Table structure for table `retur_pembelian_details_item`
--

DROP TABLE IF EXISTS `retur_pembelian_details_item`;
CREATE TABLE `retur_pembelian_details_item` (
  `retur_pembelian_details_item_id` int(11) NOT NULL,
  `purchase_id` int(11) NOT NULL,
  `retur_pembelian_details_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `kategori_keterangan` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `retur_pembelian_details_item`
--

TRUNCATE TABLE `retur_pembelian_details_item`;