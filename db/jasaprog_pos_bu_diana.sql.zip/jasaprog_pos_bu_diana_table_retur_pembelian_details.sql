
-- --------------------------------------------------------

--
-- Table structure for table `retur_pembelian_details`
--

DROP TABLE IF EXISTS `retur_pembelian_details`;
CREATE TABLE `retur_pembelian_details` (
  `retur_details_id` int(11) NOT NULL,
  `retur_id` int(11) NOT NULL,
  `purchase_id` int(11) NOT NULL,
  `purchase_detail_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `item_qty` float NOT NULL,
  `unit_id` int(11) NOT NULL,
  `item_price` bigint(11) NOT NULL,
  `retur_desc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `retur_pembelian_details`
--

TRUNCATE TABLE `retur_pembelian_details`;
--
-- Dumping data for table `retur_pembelian_details`
--

INSERT INTO `retur_pembelian_details` (`retur_details_id`, `retur_id`, `purchase_id`, `purchase_detail_id`, `item_id`, `item_qty`, `unit_id`, `item_price`, `retur_desc`) VALUES
(1, 1, 3, 2, 2, 1, 20, 12450, 'dasccfqfcxcxzc'),
(2, 2, 2, 1, 1, 1, 14, 1200000, '');
