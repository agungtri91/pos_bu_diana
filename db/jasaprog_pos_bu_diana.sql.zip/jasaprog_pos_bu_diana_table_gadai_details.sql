
-- --------------------------------------------------------

--
-- Table structure for table `gadai_details`
--

DROP TABLE IF EXISTS `gadai_details`;
CREATE TABLE `gadai_details` (
  `gadai_detail_id` int(11) NOT NULL,
  `gadai_id` int(11) NOT NULL,
  `item_image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `gadai_details`
--

TRUNCATE TABLE `gadai_details`;