
-- --------------------------------------------------------

--
-- Table structure for table `journal_types`
--

DROP TABLE IF EXISTS `journal_types`;
CREATE TABLE `journal_types` (
  `journal_type_id` int(11) NOT NULL,
  `journal_type_name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `journal_types`
--

TRUNCATE TABLE `journal_types`;
--
-- Dumping data for table `journal_types`
--

INSERT INTO `journal_types` (`journal_type_id`, `journal_type_name`) VALUES
(1, 'PEMASUKAN'),
(2, 'PENGELUARAN'),
(3, 'PENGELUARAN LAINNYA'),
(4, 'PEMASUKKAN LAINNYA'),
(5, 'PENGANGSURAN HUTANG'),
(6, 'PENGANGSURAN PIUTANG');
