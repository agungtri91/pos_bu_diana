
-- --------------------------------------------------------

--
-- Table structure for table `mutasi_barang`
--

DROP TABLE IF EXISTS `mutasi_barang`;
CREATE TABLE `mutasi_barang` (
  `mutasi_id` int(11) NOT NULL,
  `gadai_id` int(11) NOT NULL,
  `mutasi_code` varchar(11) NOT NULL,
  `mutasi_date` datetime NOT NULL,
  `cabang_asal` int(11) NOT NULL,
  `cabang_tujuan` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `mutasi_barang`
--

TRUNCATE TABLE `mutasi_barang`;
--
-- Dumping data for table `mutasi_barang`
--

INSERT INTO `mutasi_barang` (`mutasi_id`, `gadai_id`, `mutasi_code`, `mutasi_date`, `cabang_asal`, `cabang_tujuan`) VALUES
(1, 8, 'M1487656458', '2017-02-21 06:02:18', 3, 3);
