
-- --------------------------------------------------------

--
-- Table structure for table `wr_pembelian_tmp`
--

DROP TABLE IF EXISTS `wr_pembelian_tmp`;
CREATE TABLE `wr_pembelian_tmp` (
  `retur_tmp_id` int(11) NOT NULL,
  `purchase_id` int(11) NOT NULL,
  `purchase_detail_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `item_qty` float NOT NULL,
  `unit_id` int(11) NOT NULL,
  `harga_retur` bigint(20) NOT NULL,
  `retur_desc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `wr_pembelian_tmp`
--

TRUNCATE TABLE `wr_pembelian_tmp`;
--
-- Dumping data for table `wr_pembelian_tmp`
--

INSERT INTO `wr_pembelian_tmp` (`retur_tmp_id`, `purchase_id`, `purchase_detail_id`, `user_id`, `item_id`, `item_qty`, `unit_id`, `harga_retur`, `retur_desc`) VALUES
(9, 2, 1, 1, 1, 1, 14, 1200000, '');
