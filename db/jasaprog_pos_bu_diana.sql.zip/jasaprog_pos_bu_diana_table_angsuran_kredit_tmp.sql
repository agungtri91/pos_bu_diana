
-- --------------------------------------------------------

--
-- Table structure for table `angsuran_kredit_tmp`
--

DROP TABLE IF EXISTS `angsuran_kredit_tmp`;
CREATE TABLE `angsuran_kredit_tmp` (
  `angsuran_kredit_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `transaction_id` int(11) NOT NULL,
  `kredit_id` int(11) NOT NULL,
  `lama_angsuran` bigint(20) NOT NULL,
  `angsuran_nominal` bigint(20) NOT NULL,
  `total_kredit` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `angsuran_kredit_tmp`
--

TRUNCATE TABLE `angsuran_kredit_tmp`;