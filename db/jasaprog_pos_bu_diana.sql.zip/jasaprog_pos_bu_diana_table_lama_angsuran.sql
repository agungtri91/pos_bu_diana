
-- --------------------------------------------------------

--
-- Table structure for table `lama_angsuran`
--

DROP TABLE IF EXISTS `lama_angsuran`;
CREATE TABLE `lama_angsuran` (
  `lama_angsuran_id` int(11) NOT NULL,
  `lama_angsuran_name` varchar(200) NOT NULL,
  `periode` int(11) NOT NULL,
  `lama_angsuran` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `lama_angsuran`
--

TRUNCATE TABLE `lama_angsuran`;