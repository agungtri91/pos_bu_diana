
-- --------------------------------------------------------

--
-- Table structure for table `list_angsuran`
--

DROP TABLE IF EXISTS `list_angsuran`;
CREATE TABLE `list_angsuran` (
  `transactioin_id` int(11) NOT NULL,
  `angsuran` int(11) NOT NULL,
  `harga_real` int(11) NOT NULL,
  `uang_muka` int(11) NOT NULL,
  `hasil_angsuran` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `list_angsuran`
--

TRUNCATE TABLE `list_angsuran`;