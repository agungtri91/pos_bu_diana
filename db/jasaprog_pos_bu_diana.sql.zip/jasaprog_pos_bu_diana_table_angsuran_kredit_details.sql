
-- --------------------------------------------------------

--
-- Table structure for table `angsuran_kredit_details`
--

DROP TABLE IF EXISTS `angsuran_kredit_details`;
CREATE TABLE `angsuran_kredit_details` (
  `angsuran_kredit_details_id` int(11) NOT NULL,
  `angsuran_kredit_details_code` varchar(200) NOT NULL,
  `angsuran_kredit_id` int(11) NOT NULL,
  `angsuran_date` date NOT NULL,
  `payment_method` int(11) NOT NULL,
  `bank_id` int(11) NOT NULL,
  `bank_account_id` varchar(200) NOT NULL,
  `bank_id_to` int(11) NOT NULL,
  `bank_account_id_to` varchar(200) NOT NULL,
  `angsuran_nominal` bigint(20) NOT NULL,
  `total_payment` bigint(20) NOT NULL,
  `payment_change` bigint(20) NOT NULL,
  `denda_nominal` int(11) NOT NULL,
  `denda_persen` int(11) NOT NULL,
  `denda_persen_nominal` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `ket` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `angsuran_kredit_details`
--

TRUNCATE TABLE `angsuran_kredit_details`;
--
-- Dumping data for table `angsuran_kredit_details`
--

INSERT INTO `angsuran_kredit_details` (`angsuran_kredit_details_id`, `angsuran_kredit_details_code`, `angsuran_kredit_id`, `angsuran_date`, `payment_method`, `bank_id`, `bank_account_id`, `bank_id_to`, `bank_account_id_to`, `angsuran_nominal`, `total_payment`, `payment_change`, `denda_nominal`, `denda_persen`, `denda_persen_nominal`, `user_id`, `ket`) VALUES
(15, 'AK_1486708094', 1, '2017-02-10', 1, 0, '', 0, '', 3958400, 3978192, 0, 0, 1, 19792, 1, 1),
(16, 'AK_1486708747', 2, '2017-02-10', 1, 0, '', 0, '', 26000, 26130, 0, 0, 1, 130, 1, 1),
(17, 'AK_1487815850', 3, '2017-02-23', 1, 0, '', 0, '', 95000, 95475, 0, 0, 1, 475, 1, 1),
(18, 'AK_1487826391', 2, '2017-02-23', 1, 0, '', 0, '', 26000, 26000, 0, 0, 0, 0, 1, 0),
(19, 'AK_1487826515', 4, '2017-02-23', 1, 0, '', 0, '', 2055000, 2065275, 0, 0, 1, 10275, 1, 1),
(20, 'AK_1487832615', 5, '2017-02-23', 1, 0, '', 0, '', 3400000, 3417000, 0, 0, 1, 17000, 1, 1);
