
-- --------------------------------------------------------

--
-- Table structure for table `angsuran_kredit_details_tmp`
--

DROP TABLE IF EXISTS `angsuran_kredit_details_tmp`;
CREATE TABLE `angsuran_kredit_details_tmp` (
  `angsuran_kredit_details_id` int(11) NOT NULL,
  `angsuran_kredit_id` int(11) NOT NULL,
  `angsuran_date` date NOT NULL,
  `payment_method` int(11) NOT NULL,
  `angsuran_nominal` bigint(20) NOT NULL,
  `total_payment` bigint(20) NOT NULL,
  `payment_change` bigint(20) NOT NULL,
  `denda_nominal` int(11) NOT NULL,
  `denda_persen` float NOT NULL,
  `denda_persen_nominal` int(11) NOT NULL,
  `ket` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `angsuran_kredit_details_tmp`
--

TRUNCATE TABLE `angsuran_kredit_details_tmp`;