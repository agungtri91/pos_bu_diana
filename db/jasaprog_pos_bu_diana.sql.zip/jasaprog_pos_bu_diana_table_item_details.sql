
-- --------------------------------------------------------

--
-- Table structure for table `item_details`
--

DROP TABLE IF EXISTS `item_details`;
CREATE TABLE `item_details` (
  `item_detail_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `item_merk` varchar(200) NOT NULL,
  `item_tipe` varchar(200) NOT NULL,
  `item_berat` int(11) NOT NULL,
  `item_p` int(11) NOT NULL,
  `item_l` int(11) NOT NULL,
  `item_t` int(11) NOT NULL,
  `item_penerbit` text NOT NULL,
  `item_desc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `item_details`
--

TRUNCATE TABLE `item_details`;
--
-- Dumping data for table `item_details`
--

INSERT INTO `item_details` (`item_detail_id`, `item_id`, `item_merk`, `item_tipe`, `item_berat`, `item_p`, `item_l`, `item_t`, `item_penerbit`, `item_desc`) VALUES
(28, 1, 'PHILLIPS', 'LED', 0, 0, 0, 0, '', 'Edit nama stock                                                                                                                                                                    '),
(37, 13, '', '', 0, 0, 0, 0, '', ''),
(38, 2, 'PHILLIPS', 'LED', 0, 0, 0, 0, '', '                                                                                                                                                                                                                                    '),
(47, 28, 'Honda', 'Bebek Super', 0, 0, 0, 0, '', '                                                                            '),
(48, 29, 'Maspion', 'CEILING EXHAUST FAN 10â€³ CEF-2510', 0, 0, 0, 0, '', '                                                                            '),
(49, 31, 'POLYTRON', '[PRN 160B]', 0, 0, 0, 0, '', '                                      '),
(52, 39, 'Honda', '', 0, 0, 0, 0, '', '                                      '),
(53, 41, 'merk 1', 'item a c 45', 0, 0, 0, 0, '', ''),
(54, 42, 'BENDI', 'PP', 30, 100, 8, 0, '', ''),
(55, 43, 'PHILIPS', 'ELETRIK', 0, 0, 0, 0, '', '');
