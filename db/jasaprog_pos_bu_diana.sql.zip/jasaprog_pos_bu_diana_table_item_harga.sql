
-- --------------------------------------------------------

--
-- Table structure for table `item_harga`
--

DROP TABLE IF EXISTS `item_harga`;
CREATE TABLE `item_harga` (
  `stock_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `item_original_price` bigint(11) NOT NULL,
  `item_hpp_price` bigint(20) NOT NULL,
  `item_margin_price` bigint(11) NOT NULL,
  `item_price` bigint(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `item_harga`
--

TRUNCATE TABLE `item_harga`;
--
-- Dumping data for table `item_harga`
--

INSERT INTO `item_harga` (`stock_id`, `item_id`, `item_original_price`, `item_hpp_price`, `item_margin_price`, `item_price`) VALUES
(21, 1, 120, 0, 0, 1300000),
(22, 2, 0, 0, 0, 129000),
(23, 41, 0, 90000, 0, 100000),
(24, 28, 0, 0, 0, 0),
(25, 42, 0, 0, 0, 0),
(26, 43, 0, 0, 0, 0);
