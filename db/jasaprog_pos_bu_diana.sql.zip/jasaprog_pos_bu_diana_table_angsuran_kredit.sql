
-- --------------------------------------------------------

--
-- Table structure for table `angsuran_kredit`
--

DROP TABLE IF EXISTS `angsuran_kredit`;
CREATE TABLE `angsuran_kredit` (
  `angsuran_kredit_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `transaction_id` int(11) NOT NULL,
  `kredit_id` int(11) NOT NULL,
  `lama_angsuran` bigint(20) NOT NULL,
  `angsuran_nominal` bigint(20) NOT NULL,
  `total_kredit` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `angsuran_kredit`
--

TRUNCATE TABLE `angsuran_kredit`;
--
-- Dumping data for table `angsuran_kredit`
--

INSERT INTO `angsuran_kredit` (`angsuran_kredit_id`, `member_id`, `transaction_id`, `kredit_id`, `lama_angsuran`, `angsuran_nominal`, `total_kredit`) VALUES
(1, 33, 2, 2, 6, 3958400, 0),
(2, 27, 1, 1, 4, 26000, 0),
(3, 32, 4, 4, 2, 95000, 0),
(4, 31, 3, 3, 12, 2055000, 0),
(5, 30, 5, 5, 7, 3400000, 0);
