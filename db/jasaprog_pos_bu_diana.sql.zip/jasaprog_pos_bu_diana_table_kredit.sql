
-- --------------------------------------------------------

--
-- Table structure for table `kredit`
--

DROP TABLE IF EXISTS `kredit`;
CREATE TABLE `kredit` (
  `kredit_id` int(11) NOT NULL,
  `transaction_id` int(11) NOT NULL,
  `transaction_date` date NOT NULL,
  `batas_tanggal_angsuran` date NOT NULL,
  `kredit_code` varchar(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `uang_muka_barang` bigint(20) NOT NULL,
  `payment_method_id` int(11) NOT NULL,
  `bank_id_angsuran` int(11) NOT NULL,
  `bank_account_angsuran` varchar(200) NOT NULL,
  `bank_id_to_angsuran` int(11) NOT NULL,
  `bank_account_to_angsuran` varchar(200) NOT NULL,
  `lunas` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `kredit`
--

TRUNCATE TABLE `kredit`;
--
-- Dumping data for table `kredit`
--

INSERT INTO `kredit` (`kredit_id`, `transaction_id`, `transaction_date`, `batas_tanggal_angsuran`, `kredit_code`, `user_id`, `member_id`, `uang_muka_barang`, `payment_method_id`, `bank_id_angsuran`, `bank_account_angsuran`, `bank_id_to_angsuran`, `bank_account_to_angsuran`, `lunas`) VALUES
(1, 8, '0000-00-00', '0000-00-00', '5', 1, 0, 200000, 5, 0, '', 0, '', 0),
(2, 9, '2017-05-07', '0000-00-00', '51494183594', 1, 30, 800000, 5, 0, '', 0, '', 0),
(3, 10, '2017-05-28', '0000-00-00', '51496001150', 1, 31, 130000000, 5, 0, '', 0, '', 0),
(4, 14, '2017-07-27', '0000-00-00', '51501146603', 1, 30, 24024000, 5, 0, '', 0, '', 0),
(5, 15, '2017-07-31', '0000-00-00', '51501475640', 1, 30, 4019246, 5, 0, '', 0, '', 0);
