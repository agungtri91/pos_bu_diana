
-- --------------------------------------------------------

--
-- Table structure for table `transaction_details_item`
--

DROP TABLE IF EXISTS `transaction_details_item`;
CREATE TABLE `transaction_details_item` (
  `transaction_details_item` int(11) NOT NULL,
  `transaction_id` int(11) NOT NULL,
  `transaction_detail_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `keterangan_item` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `transaction_details_item`
--

TRUNCATE TABLE `transaction_details_item`;
--
-- Dumping data for table `transaction_details_item`
--

INSERT INTO `transaction_details_item` (`transaction_details_item`, `transaction_id`, `transaction_detail_id`, `item_id`, `keterangan_item`) VALUES
(9, 1, 3, 1, 1),
(10, 2, 4, 1, 0),
(11, 2, 4, 1, 0),
(12, 2, 4, 1, 4);
