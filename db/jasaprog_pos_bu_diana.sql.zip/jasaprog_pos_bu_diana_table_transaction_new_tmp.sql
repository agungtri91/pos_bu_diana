
-- --------------------------------------------------------

--
-- Table structure for table `transaction_new_tmp`
--

DROP TABLE IF EXISTS `transaction_new_tmp`;
CREATE TABLE `transaction_new_tmp` (
  `tnt_id` int(11) NOT NULL,
  `table_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `tnt_price` int(11) NOT NULL,
  `tnt_discount` int(11) NOT NULL,
  `tnt_grand_price` int(11) NOT NULL,
  `tnt_qty` int(11) NOT NULL,
  `tnt_total` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `transaction_new_tmp`
--

TRUNCATE TABLE `transaction_new_tmp`;