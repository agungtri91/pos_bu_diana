
-- --------------------------------------------------------

--
-- Table structure for table `units`
--

DROP TABLE IF EXISTS `units`;
CREATE TABLE `units` (
  `unit_id` int(11) NOT NULL,
  `unit_name` varchar(20) NOT NULL,
  `satuan` decimal(10,0) NOT NULL,
  `tingkat` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `units`
--

TRUNCATE TABLE `units`;
--
-- Dumping data for table `units`
--

INSERT INTO `units` (`unit_id`, `unit_name`, `satuan`, `tingkat`) VALUES
(20, 'DOS', '0', 0),
(14, 'Unit', '0', 0),
(24, 'roll', '0', 0),
(23, 'zak', '0', 0),
(22, 'Buah', '0', 0),
(25, 'LUSIN', '0', 0);
