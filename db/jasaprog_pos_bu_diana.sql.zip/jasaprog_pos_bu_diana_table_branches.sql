
-- --------------------------------------------------------

--
-- Table structure for table `branches`
--

DROP TABLE IF EXISTS `branches`;
CREATE TABLE `branches` (
  `branch_id` int(11) NOT NULL,
  `branch_name` varchar(200) NOT NULL,
  `branch_img` text NOT NULL,
  `branch_desc` text NOT NULL,
  `branch_address` text NOT NULL,
  `branch_phone` varchar(100) NOT NULL,
  `branch_city` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `branches`
--

TRUNCATE TABLE `branches`;
--
-- Dumping data for table `branches`
--

INSERT INTO `branches` (`branch_id`, `branch_name`, `branch_img`, `branch_desc`, `branch_address`, `branch_phone`, `branch_city`) VALUES
(3, 'PUSAT', '', '-', 'Jl. Kesejahteraan', '0989906', 'SURABAYA'),
(4, 'CABANG 2', '', '', '', '', ''),
(5, 'asas', '1485753450_ionic.PNG', '', '', '', ''),
(6, '1212', '', 'qwqwqw', 'qwqw', 'qwqw', 'wqwq'),
(7, 'CABANG A', '', 'coba edit cabang', 'kedung tarukan', '098-837-123', 'surabaya'),
(9, 'BRANCH', '', 'SKMAKSM', 'SANA', '1234', 'SURABAYA'),
(10, 'RANTING', '', 'AKJSKJAKJ', 'SITU', '090909090', 'GRESIK'),
(11, 'MULIA', '', '', 'JL. AYANI NO 6', '888888', 'JB');
