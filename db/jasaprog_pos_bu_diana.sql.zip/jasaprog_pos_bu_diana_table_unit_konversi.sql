
-- --------------------------------------------------------

--
-- Table structure for table `unit_konversi`
--

DROP TABLE IF EXISTS `unit_konversi`;
CREATE TABLE `unit_konversi` (
  `unit_konversi_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `unit_jml` bigint(20) NOT NULL,
  `unit_id` int(11) NOT NULL,
  `unit_konversi_jml` bigint(20) NOT NULL,
  `unit_konversi` int(255) NOT NULL,
  `harga_konversi` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `unit_konversi`
--

TRUNCATE TABLE `unit_konversi`;
--
-- Dumping data for table `unit_konversi`
--

INSERT INTO `unit_konversi` (`unit_konversi_id`, `item_id`, `unit_jml`, `unit_id`, `unit_konversi_jml`, `unit_konversi`, `harga_konversi`) VALUES
(38, 2, 1, 20, 20, 14, 129000),
(40, 41, 1, 20, 10, 14, 12000),
(41, 41, 1, 14, 5, 22, 8000),
(43, 0, 1, 20, 40, 24, 0),
(44, 0, 0, 0, 0, 0, 0),
(45, 1, 12, 14, 1, 20, 130000000),
(46, 1, 0, 0, 0, 0, 0);
