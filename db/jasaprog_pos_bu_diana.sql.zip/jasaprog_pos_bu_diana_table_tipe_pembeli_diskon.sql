
-- --------------------------------------------------------

--
-- Table structure for table `tipe_pembeli_diskon`
--

DROP TABLE IF EXISTS `tipe_pembeli_diskon`;
CREATE TABLE `tipe_pembeli_diskon` (
  `tipe_pembeli_diskon_id` int(11) NOT NULL,
  `tipe_pembeli` int(11) NOT NULL,
  `kategori_item` int(11) NOT NULL,
  `nilai_diskon` int(11) NOT NULL,
  `nominal_diskon` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `tipe_pembeli_diskon`
--

TRUNCATE TABLE `tipe_pembeli_diskon`;
--
-- Dumping data for table `tipe_pembeli_diskon`
--

INSERT INTO `tipe_pembeli_diskon` (`tipe_pembeli_diskon_id`, `tipe_pembeli`, `kategori_item`, `nilai_diskon`, `nominal_diskon`) VALUES
(3, 15, 6, 12, 0),
(4, 16, 6, 12, 0),
(5, 14, 6, 12, 0);
