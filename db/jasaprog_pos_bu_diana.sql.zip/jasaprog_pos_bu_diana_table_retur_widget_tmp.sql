
-- --------------------------------------------------------

--
-- Table structure for table `retur_widget_tmp`
--

DROP TABLE IF EXISTS `retur_widget_tmp`;
CREATE TABLE `retur_widget_tmp` (
  `retur_tmp_id` int(11) NOT NULL,
  `transaction_id` int(11) NOT NULL,
  `transaction_detail_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `item_qty` int(11) NOT NULL,
  `unit_id_jual` int(11) NOT NULL,
  `unit_id_retur` int(11) NOT NULL,
  `harga_konversi` bigint(20) NOT NULL,
  `harga_total` bigint(20) NOT NULL,
  `retur_desc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `retur_widget_tmp`
--

TRUNCATE TABLE `retur_widget_tmp`;