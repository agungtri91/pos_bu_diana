
-- --------------------------------------------------------

--
-- Table structure for table `gadai_tmp_details`
--

DROP TABLE IF EXISTS `gadai_tmp_details`;
CREATE TABLE `gadai_tmp_details` (
  `gadai_detail_id` int(11) NOT NULL,
  `gadai_id` int(11) NOT NULL,
  `item_image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `gadai_tmp_details`
--

TRUNCATE TABLE `gadai_tmp_details`;
--
-- Dumping data for table `gadai_tmp_details`
--

INSERT INTO `gadai_tmp_details` (`gadai_detail_id`, `gadai_id`, `item_image`) VALUES
(8, 8, 'CRZ-R_02.jpg'),
(9, 8, 'MY16_CRZ_exterior_1.jpg'),
(10, 9, 'ionic.PNG'),
(11, 9, 'tab_order.PNG');
