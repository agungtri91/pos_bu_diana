
-- --------------------------------------------------------

--
-- Table structure for table `retur_details_pembelian_tmp`
--

DROP TABLE IF EXISTS `retur_details_pembelian_tmp`;
CREATE TABLE `retur_details_pembelian_tmp` (
  `retur_details_id` int(11) NOT NULL,
  `purchase_id` int(11) NOT NULL,
  `purchase_detail_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `item_qty` float NOT NULL,
  `unit_id` int(11) NOT NULL,
  `item_price` bigint(11) NOT NULL,
  `item_price_total` bigint(20) NOT NULL,
  `retur_desc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `retur_details_pembelian_tmp`
--

TRUNCATE TABLE `retur_details_pembelian_tmp`;
--
-- Dumping data for table `retur_details_pembelian_tmp`
--

INSERT INTO `retur_details_pembelian_tmp` (`retur_details_id`, `purchase_id`, `purchase_detail_id`, `item_id`, `item_qty`, `unit_id`, `item_price`, `item_price_total`, `retur_desc`) VALUES
(2, 2, 1, 1, 1, 14, 1200000, 1200000, '');
