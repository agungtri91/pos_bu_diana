
-- --------------------------------------------------------

--
-- Table structure for table `retur_details`
--

DROP TABLE IF EXISTS `retur_details`;
CREATE TABLE `retur_details` (
  `retur_details_id` int(11) NOT NULL,
  `retur_id` int(11) NOT NULL,
  `transaction_id` int(11) NOT NULL,
  `transaction_detail_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `unit_id` int(11) NOT NULL,
  `item_qty` float NOT NULL,
  `item_price` bigint(11) NOT NULL,
  `item_price_total` bigint(20) NOT NULL,
  `retur_desc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `retur_details`
--

TRUNCATE TABLE `retur_details`;
--
-- Dumping data for table `retur_details`
--

INSERT INTO `retur_details` (`retur_details_id`, `retur_id`, `transaction_id`, `transaction_detail_id`, `item_id`, `unit_id`, `item_qty`, `item_price`, `item_price_total`, `retur_desc`) VALUES
(1, 2, 1, 3, 1, 1, 14, 1400000, 1400000, '');
