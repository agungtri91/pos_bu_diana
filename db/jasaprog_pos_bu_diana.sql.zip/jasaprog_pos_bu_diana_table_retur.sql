
-- --------------------------------------------------------

--
-- Table structure for table `retur`
--

DROP TABLE IF EXISTS `retur`;
CREATE TABLE `retur` (
  `retur_id` int(11) NOT NULL,
  `transaction_id` int(11) NOT NULL,
  `transaction_date` date NOT NULL,
  `retur_date` date NOT NULL,
  `payment_method` int(11) NOT NULL,
  `bank_id_1` int(11) NOT NULL,
  `bank_account_1` int(11) NOT NULL,
  `bank_id_2` int(11) NOT NULL,
  `bank_account_2` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `retur_total_price` bigint(11) NOT NULL,
  `retur_payment` bigint(20) NOT NULL,
  `retur_change` bigint(20) NOT NULL,
  `lunas` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `retur`
--

TRUNCATE TABLE `retur`;
--
-- Dumping data for table `retur`
--

INSERT INTO `retur` (`retur_id`, `transaction_id`, `transaction_date`, `retur_date`, `payment_method`, `bank_id_1`, `bank_account_1`, `bank_id_2`, `bank_account_2`, `user_id`, `retur_total_price`, `retur_payment`, `retur_change`, `lunas`) VALUES
(1, 0, '0000-00-00', '0000-00-00', 1, 0, 0, 0, 0, 1, 0, 1400000, 0, 0),
(2, 0, '0000-00-00', '0000-00-00', 1, 0, 0, 0, 0, 1, 0, 1400000, 0, 0);
