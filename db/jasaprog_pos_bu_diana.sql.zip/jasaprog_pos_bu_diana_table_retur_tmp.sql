
-- --------------------------------------------------------

--
-- Table structure for table `retur_tmp`
--

DROP TABLE IF EXISTS `retur_tmp`;
CREATE TABLE `retur_tmp` (
  `retur_id` int(11) NOT NULL,
  `transaction_id` int(11) NOT NULL,
  `retur_date` date NOT NULL,
  `transaction_date` date NOT NULL,
  `retur_total_price` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `lunas` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `retur_tmp`
--

TRUNCATE TABLE `retur_tmp`;