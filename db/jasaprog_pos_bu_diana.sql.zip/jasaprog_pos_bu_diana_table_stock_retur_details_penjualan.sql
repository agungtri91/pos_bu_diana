
-- --------------------------------------------------------

--
-- Table structure for table `stock_retur_details_penjualan`
--

DROP TABLE IF EXISTS `stock_retur_details_penjualan`;
CREATE TABLE `stock_retur_details_penjualan` (
  `item_stock_detail_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `transaction_id` int(11) NOT NULL,
  `transaction_detail_id` int(11) NOT NULL,
  `item_stock_real` bigint(20) NOT NULL,
  `item_stock_qty` bigint(11) NOT NULL,
  `unit_id` int(11) NOT NULL,
  `retur_date` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `stock_retur_details_penjualan`
--

TRUNCATE TABLE `stock_retur_details_penjualan`;
--
-- Dumping data for table `stock_retur_details_penjualan`
--

INSERT INTO `stock_retur_details_penjualan` (`item_stock_detail_id`, `item_id`, `member_id`, `transaction_id`, `transaction_detail_id`, `item_stock_real`, `item_stock_qty`, `unit_id`, `retur_date`) VALUES
(2, 1, 27, 1, 4, 1, 1, 14, 2017),
(3, 2, 30, 5, 8, 1, 1, 20, 2017),
(4, 1, 34, 1, 3, 1, 1, 14, 0),
(5, 1, 34, 1, 3, 1, 1, 14, 0),
(6, 1, 34, 1, 3, 1, 1, 14, 0),
(7, 1, 34, 1, 3, 1, 1, 14, 0),
(8, 1, 34, 1, 3, 1, 1, 14, 0),
(9, 1, 34, 1, 3, 1, 1, 14, 0),
(10, 1, 34, 1, 3, 1, 1, 14, 0),
(11, 1, 34, 1, 3, 1, 1, 14, 0),
(12, 1, 34, 1, 3, 1, 1, 14, 0),
(13, 1, 34, 1, 3, 1, 1, 14, 0),
(14, 1, 34, 1, 3, 1, 1, 14, 0),
(15, 1, 34, 1, 3, 1, 1, 14, 0),
(16, 1, 34, 1, 3, 1, 1, 14, 0),
(17, 1, 34, 1, 3, 1, 1, 14, 0),
(18, 1, 34, 1, 3, 1, 1, 14, 0),
(19, 1, 34, 1, 3, 1, 1, 14, 0),
(20, 1, 34, 1, 3, 1, 1, 14, 0);
