
-- --------------------------------------------------------

--
-- Table structure for table `transaction_details`
--

DROP TABLE IF EXISTS `transaction_details`;
CREATE TABLE `transaction_details` (
  `transaction_detail_id` int(11) NOT NULL,
  `transaction_id` int(11) NOT NULL,
  `kategori` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `transaction_detail_original_price` bigint(11) NOT NULL,
  `transaction_detail_margin_price` bigint(11) NOT NULL,
  `transaction_detail_price` bigint(11) NOT NULL,
  `transaction_detail_persen_discount` int(11) NOT NULL,
  `transaction_detail_persen_discount_total` int(11) NOT NULL,
  `transaction_detail_nominal_discount` bigint(20) NOT NULL,
  `transaction_detail_nominal_discount_total` int(11) NOT NULL,
  `transaction_detail_qty_real` bigint(11) NOT NULL,
  `transaction_detail_qty` float NOT NULL,
  `transaction_detail_unit` int(11) NOT NULL,
  `transaction_detail_total` int(11) NOT NULL,
  `retur` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `transaction_details`
--

TRUNCATE TABLE `transaction_details`;
--
-- Dumping data for table `transaction_details`
--

INSERT INTO `transaction_details` (`transaction_detail_id`, `transaction_id`, `kategori`, `item_id`, `transaction_detail_original_price`, `transaction_detail_margin_price`, `transaction_detail_price`, `transaction_detail_persen_discount`, `transaction_detail_persen_discount_total`, `transaction_detail_nominal_discount`, `transaction_detail_nominal_discount_total`, `transaction_detail_qty_real`, `transaction_detail_qty`, `transaction_detail_unit`, `transaction_detail_total`, `retur`) VALUES
(1, 2, 6, 1, 1300000, 0, 1300000, 0, 0, 0, 0, 1, 1, 14, 1300000, 0),
(2, 4, 6, 1, 1300000, 0, 1300000, 12, 156000, 0, 0, 1, 1, 14, 1300000, 0),
(3, 5, 6, 1, 1300000, 0, 1300000, 0, 0, 0, 0, 1, 1, 14, 1300000, 0),
(4, 6, 6, 2, 129000, 0, 129000, 0, 0, 0, 0, 2, 2, 20, 258000, 0),
(5, 7, 6, 1, 1300000, 0, 1300000, 12, 312000, 0, 0, 2, 2, 14, 2600000, 0),
(6, 9, 6, 1, 1300000, 0, 1300000, 12, 156000, 0, 0, 1, 1, 14, 1300000, 0),
(7, 10, 6, 1, 1300000, 0, 1300000, 0, 0, 0, 0, 100, 1, 20, 130000000, 0),
(8, 11, 6, 1, 1300000, 0, 1300000, 12, 156000, 0, 0, 1, 1, 14, 1300000, 0),
(9, 11, 6, 1, 1300000, 0, 1300000, 12, 312000, 0, 0, 1, 1, 14, 1300000, 0),
(10, 12, 6, 2, 129000, 0, 129000, 0, 0, 0, 0, 1, 1, 20, 129000, 0),
(11, 13, 6, 2, 129000, 0, 129000, 12, 15480, 0, 0, 1, 1, 20, 129000, 0),
(12, 14, 6, 1, 1300000, 0, 1300000, 12, 3276000, 0, 0, 21, 21, 14, 27300000, 0),
(13, 15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(14, 15, 6, 1, 1300000, 0, 1300000, 12, 468000, 0, 0, 3, 3, 14, 3900000, 0),
(15, 15, 6, 2, 129000, 0, 129000, 12, 484254, 0, 0, 1, 2, 14, 135450, 0),
(16, 16, 6, 1, 1300000, 0, 1300000, 0, 0, 0, 0, 7, 7, 14, 9100000, 0),
(17, 16, 6, 2, 129000, 0, 129000, 0, 0, 0, 0, 2, 2, 20, 258000, 0);
