
-- --------------------------------------------------------

--
-- Table structure for table `jenis_pembeli`
--

DROP TABLE IF EXISTS `jenis_pembeli`;
CREATE TABLE `jenis_pembeli` (
  `jenis_pembeli_id` int(11) NOT NULL,
  `jenis_pembeli_name` varchar(200) NOT NULL,
  `jumlah_terlambat_bayar` int(20) NOT NULL,
  `jenis_pembeli_color` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `jenis_pembeli`
--

TRUNCATE TABLE `jenis_pembeli`;
--
-- Dumping data for table `jenis_pembeli`
--

INSERT INTO `jenis_pembeli` (`jenis_pembeli_id`, `jenis_pembeli_name`, `jumlah_terlambat_bayar`, `jenis_pembeli_color`) VALUES
(1, 'Sering Terlambat', 3, '#ff0000'),
(2, 'Rajin ', 0, '');
