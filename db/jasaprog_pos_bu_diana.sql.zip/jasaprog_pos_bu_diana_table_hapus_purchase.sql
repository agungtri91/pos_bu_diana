
-- --------------------------------------------------------

--
-- Table structure for table `hapus_purchase`
--

DROP TABLE IF EXISTS `hapus_purchase`;
CREATE TABLE `hapus_purchase` (
  `hapus_id` int(11) NOT NULL,
  `user_id_hapus` int(11) NOT NULL,
  `purchases_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `purchases_date` datetime NOT NULL,
  `purchases_code` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `bank_id` int(11) NOT NULL,
  `bank_account` int(11) NOT NULL,
  `bank_id_to` int(11) NOT NULL,
  `bank_account_to` int(11) NOT NULL,
  `payment_method` int(11) NOT NULL,
  `purchase_total` bigint(11) NOT NULL,
  `purchase_payment` bigint(11) NOT NULL,
  `purchase_change` bigint(11) NOT NULL,
  `lunas` int(11) NOT NULL,
  `purchase_desc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `hapus_purchase`
--

TRUNCATE TABLE `hapus_purchase`;
--
-- Dumping data for table `hapus_purchase`
--

INSERT INTO `hapus_purchase` (`hapus_id`, `user_id_hapus`, `purchases_id`, `user_id`, `purchases_date`, `purchases_code`, `supplier_id`, `branch_id`, `bank_id`, `bank_account`, `bank_id_to`, `bank_account_to`, `payment_method`, `purchase_total`, `purchase_payment`, `purchase_change`, `lunas`, `purchase_desc`) VALUES
(1, 1, 4, 1, '2017-01-12 17:06:51', 1484237499, 1, 3, 0, 0, 0, 0, 5, 1050000, 1050000, 0, 1, '');
