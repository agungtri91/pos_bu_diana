
-- --------------------------------------------------------

--
-- Table structure for table `side_menus`
--

DROP TABLE IF EXISTS `side_menus`;
CREATE TABLE `side_menus` (
  `side_menu_id` int(11) NOT NULL,
  `side_menu_name` varchar(100) NOT NULL,
  `side_menu_url` varchar(100) NOT NULL,
  `side_menu_parent` int(11) NOT NULL,
  `side_menu_icon` varchar(100) NOT NULL,
  `side_menu_level` int(11) NOT NULL,
  `side_menu_type_parent` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `side_menus`
--

TRUNCATE TABLE `side_menus`;
--
-- Dumping data for table `side_menus`
--

INSERT INTO `side_menus` (`side_menu_id`, `side_menu_name`, `side_menu_url`, `side_menu_parent`, `side_menu_icon`, `side_menu_level`, `side_menu_type_parent`) VALUES
(0, 'tipe customer', 'type_pembeli.php', 0, '', 0, 0),
(1, 'Master', '#', 0, 'fa fa-edit', 1, 0),
(2, 'Penjualan', 'transaction_new.php', 5, 'fa fa-shopping-cart', 2, 1),
(3, 'Pembelian', 'purchase.php', 5, 'fa fa-shopping-cart', 2, 1),
(5, 'Transaksi', '#', 0, 'fa fa-shopping-cart', 1, 0),
(6, 'Accounting', '#', 0, 'fa fa-list-alt', 0, 0),
(7, 'Laporan', '#', 0, 'fa fa-book', 1, 0),
(8, 'Setting', '#', 0, 'fa fa-cog', 1, 0),
(10, 'Cabang', 'branch.php', 1, '', 2, 1),
(11, 'Stock', 'stock.php', 1, '', 2, 1),
(12, 'Item Stock Cabang', 'stock_master.php', 1, '', 2, 1),
(13, 'Stock Retur', 'stock_retur.php', 1, '', 2, 1),
(14, 'Stock Gadai', 'stock_gadai.php', 0, '', 0, 0),
(15, 'Satuan', 'satuan.php', 1, '', 2, 1),
(16, 'Tipe Customer', 'tipe_pembeli.php', 1, '', 2, 1),
(17, 'Customer', 'member.php', 1, '', 2, 1),
(18, 'Kategori Item', 'kategori.php', 1, '', 2, 1),
(20, 'Supplier', 'supplier.php', 1, '', 2, 1),
(21, 'Bank', 'bank.php', 1, '', 2, 1),
(23, 'Angsuran Piutang / Kredit', 'angsuran.php', 4, '', 2, 1),
(24, 'Angsuran Hutang', 'angsuranhut.php', 4, '', 2, 1),
(25, 'Arus Kas', 'arus_kas.php', 7, '', 2, 1),
(26, 'Pemasukan Dan Pengeluaran Lainnya', 'jurnal_umum.php', 5, '', 2, 1),
(27, 'Laporan Detail', 'report_detail.php', 7, '', 2, 1),
(28, 'Laporan Harian', 'report_harian.php', 0, '', 0, 0),
(29, 'Laporan Piutang', 'piutang.php', 7, '', 2, 1),
(30, 'Laporan hutang', 'utang.php', 7, '', 2, 1),
(31, 'Profil', 'office.php', 8, '', 2, 1),
(32, 'User', 'user.php', 8, '', 2, 1),
(33, 'Type User', 'user_type.php', 8, '', 2, 1),
(34, 'Retur penjualan', 'retur.php', 4, '', 2, 1),
(35, 'Retur pembelian', 'retur_pembelian.php', 4, '', 2, 1),
(36, 'Laporan retur penjualan', 'returdetail.php', 7, '', 2, 1),
(37, 'Laporan retur pembelian', 'retur_pembelian_detail.php', 7, '', 2, 1),
(38, 'Tipe Item', 'tipeitem.php', 0, '', 0, 0),
(39, 'Penyesuaian Stock', 'penyesuaian_stock.php', 5, '', 2, 1),
(40, 'Laporan penyesuaian stock', 'report_penyesuaian_stock.php', 7, '', 2, 1),
(41, 'Laporan Uang Kasir', 'report_uang_kasir.php', 7, '', 2, 1),
(42, 'Laporan Hapus Transaksi', 'report_edit_transaksi.php', 7, '', 2, 1),
(43, 'Partner', 'partner.php', 0, '', 0, 0),
(44, 'Denda', 'denda.php', 0, '', 0, 0);
