
-- --------------------------------------------------------

--
-- Table structure for table `retur_details_tmp`
--

DROP TABLE IF EXISTS `retur_details_tmp`;
CREATE TABLE `retur_details_tmp` (
  `retur_details_id` int(11) NOT NULL,
  `transaction_id` int(11) NOT NULL,
  `transaction_detail_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `item_qty` float NOT NULL,
  `unit_id` int(11) NOT NULL,
  `item_price` bigint(11) NOT NULL,
  `item_price_total` bigint(20) NOT NULL,
  `retur_desc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `retur_details_tmp`
--

TRUNCATE TABLE `retur_details_tmp`;