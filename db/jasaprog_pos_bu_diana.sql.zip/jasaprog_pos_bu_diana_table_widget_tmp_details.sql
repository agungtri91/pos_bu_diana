
-- --------------------------------------------------------

--
-- Table structure for table `widget_tmp_details`
--

DROP TABLE IF EXISTS `widget_tmp_details`;
CREATE TABLE `widget_tmp_details` (
  `wtd_id` int(11) NOT NULL,
  `wt_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `keterangan_item` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `widget_tmp_details`
--

TRUNCATE TABLE `widget_tmp_details`;
--
-- Dumping data for table `widget_tmp_details`
--

INSERT INTO `widget_tmp_details` (`wtd_id`, `wt_id`, `item_id`, `keterangan_item`) VALUES
(2, 0, 1, 0);
