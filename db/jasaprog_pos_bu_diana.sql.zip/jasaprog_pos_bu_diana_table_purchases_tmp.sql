
-- --------------------------------------------------------

--
-- Table structure for table `purchases_tmp`
--

DROP TABLE IF EXISTS `purchases_tmp`;
CREATE TABLE `purchases_tmp` (
  `purchases_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `purchases_date` datetime NOT NULL,
  `purchases_code` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `purchases_tmp`
--

TRUNCATE TABLE `purchases_tmp`;