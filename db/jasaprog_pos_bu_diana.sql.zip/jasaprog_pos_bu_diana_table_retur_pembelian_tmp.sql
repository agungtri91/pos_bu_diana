
-- --------------------------------------------------------

--
-- Table structure for table `retur_pembelian_tmp`
--

DROP TABLE IF EXISTS `retur_pembelian_tmp`;
CREATE TABLE `retur_pembelian_tmp` (
  `retur_id` int(11) NOT NULL,
  `purchase_id` int(11) NOT NULL,
  `retur_date` date NOT NULL,
  `purchase_date` date NOT NULL,
  `retur_total_price` bigint(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `lunas` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `retur_pembelian_tmp`
--

TRUNCATE TABLE `retur_pembelian_tmp`;
--
-- Dumping data for table `retur_pembelian_tmp`
--

INSERT INTO `retur_pembelian_tmp` (`retur_id`, `purchase_id`, `retur_date`, `purchase_date`, `retur_total_price`, `user_id`, `lunas`) VALUES
(2, 2, '2017-03-05', '2017-03-04', 1200, 1, 0);
