
-- --------------------------------------------------------

--
-- Table structure for table `hapus_transactions`
--

DROP TABLE IF EXISTS `hapus_transactions`;
CREATE TABLE `hapus_transactions` (
  `hapus_id` int(11) NOT NULL,
  `user_id_hapus` int(11) DEFAULT NULL,
  `transaction_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `transaction_date` datetime NOT NULL,
  `transaction_total` bigint(11) NOT NULL,
  `transaction_discount` bigint(11) NOT NULL,
  `transaction_grand_total` bigint(11) NOT NULL,
  `transaction_payment` bigint(11) NOT NULL,
  `transaction_change` bigint(11) NOT NULL,
  `payment_method_id` int(11) NOT NULL,
  `bank_id` int(11) NOT NULL,
  `i_bank_account` int(11) NOT NULL,
  `bank_id_to` int(11) NOT NULL,
  `i_bank_account_to` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `transaction_code` int(11) NOT NULL,
  `tax` bigint(11) NOT NULL,
  `total_all` bigint(11) NOT NULL,
  `transaction_desc` text NOT NULL,
  `lunas` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `hapus_transactions`
--

TRUNCATE TABLE `hapus_transactions`;
--
-- Dumping data for table `hapus_transactions`
--

INSERT INTO `hapus_transactions` (`hapus_id`, `user_id_hapus`, `transaction_id`, `member_id`, `transaction_date`, `transaction_total`, `transaction_discount`, `transaction_grand_total`, `transaction_payment`, `transaction_change`, `payment_method_id`, `bank_id`, `i_bank_account`, `bank_id_to`, `i_bank_account_to`, `user_id`, `transaction_code`, `tax`, `total_all`, `transaction_desc`, `lunas`, `branch_id`) VALUES
(1, 1, 2, 2, '2017-01-13 03:39:05', 0, 0, 1936000, 200000, 0, 5, 0, 0, 0, 0, 1, 1484275145, 0, 1936000, '', 1, 3);
