
-- --------------------------------------------------------

--
-- Table structure for table `gudang_identitas`
--

DROP TABLE IF EXISTS `gudang_identitas`;
CREATE TABLE `gudang_identitas` (
  `gudang_id` int(11) NOT NULL,
  `gudang_name` varchar(300) NOT NULL,
  `gudang_address` varchar(300) NOT NULL,
  `gudang_phone` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `gudang_identitas`
--

TRUNCATE TABLE `gudang_identitas`;