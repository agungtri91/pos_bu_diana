
-- --------------------------------------------------------

--
-- Table structure for table `retur_detail_item`
--

DROP TABLE IF EXISTS `retur_detail_item`;
CREATE TABLE `retur_detail_item` (
  `retur_detail_item_id` int(11) NOT NULL,
  `retur_id` int(11) NOT NULL,
  `retur_detai_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `keterangan_item` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `retur_detail_item`
--

TRUNCATE TABLE `retur_detail_item`;
--
-- Dumping data for table `retur_detail_item`
--

INSERT INTO `retur_detail_item` (`retur_detail_item_id`, `retur_id`, `retur_detai_id`, `item_id`, `keterangan_item`) VALUES
(1, 2, 1, 1, 1);
