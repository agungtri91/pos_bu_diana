
-- --------------------------------------------------------

--
-- Table structure for table `wr_pembelian_details_tmp`
--

DROP TABLE IF EXISTS `wr_pembelian_details_tmp`;
CREATE TABLE `wr_pembelian_details_tmp` (
  `wr_pembelian_details_id` int(11) NOT NULL,
  `purchase_id` int(11) NOT NULL,
  `retur_tmp_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `kategori_keterangan_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `wr_pembelian_details_tmp`
--

TRUNCATE TABLE `wr_pembelian_details_tmp`;
--
-- Dumping data for table `wr_pembelian_details_tmp`
--

INSERT INTO `wr_pembelian_details_tmp` (`wr_pembelian_details_id`, `purchase_id`, `retur_tmp_id`, `item_id`, `kategori_keterangan_id`) VALUES
(5, 2, 9, 1, 2);
