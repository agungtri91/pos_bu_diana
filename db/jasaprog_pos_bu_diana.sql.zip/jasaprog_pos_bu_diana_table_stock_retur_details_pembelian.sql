
-- --------------------------------------------------------

--
-- Table structure for table `stock_retur_details_pembelian`
--

DROP TABLE IF EXISTS `stock_retur_details_pembelian`;
CREATE TABLE `stock_retur_details_pembelian` (
  `item_stock_detail_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `purchase_id` int(11) NOT NULL,
  `purchase_detail_id` int(11) NOT NULL,
  `item_stock_real` bigint(20) NOT NULL,
  `item_stock_qty` bigint(11) NOT NULL,
  `unit_id` int(11) NOT NULL,
  `retur_date` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `stock_retur_details_pembelian`
--

TRUNCATE TABLE `stock_retur_details_pembelian`;
--
-- Dumping data for table `stock_retur_details_pembelian`
--

INSERT INTO `stock_retur_details_pembelian` (`item_stock_detail_id`, `item_id`, `supplier_id`, `purchase_id`, `purchase_detail_id`, `item_stock_real`, `item_stock_qty`, `unit_id`, `retur_date`) VALUES
(3, 2, 1, 3, 2, 1, 1, 20, 2017),
(4, 2, 1, 3, 2, 1, 1, 20, 2017),
(5, 2, 1, 3, 2, 1, 1, 20, 2017),
(6, 1, 1, 2, 1, 1, 1, 14, 2017);
