
-- --------------------------------------------------------

--
-- Table structure for table `penyesuaian_stock_cabang`
--

DROP TABLE IF EXISTS `penyesuaian_stock_cabang`;
CREATE TABLE `penyesuaian_stock_cabang` (
  `penyesuaian_stock_cabang_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `date_penyesuaian` datetime NOT NULL,
  `item_id` int(11) NOT NULL,
  `item_qty_awal` bigint(20) NOT NULL,
  `item_qty_new` bigint(20) NOT NULL,
  `status_rak` int(11) NOT NULL,
  `rak_id` int(11) NOT NULL,
  `rak_row` int(11) NOT NULL,
  `rak_col` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `penyesuaian_stock_cabang`
--

TRUNCATE TABLE `penyesuaian_stock_cabang`;