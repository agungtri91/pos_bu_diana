
-- --------------------------------------------------------

--
-- Table structure for table `purchases_details_tmp`
--

DROP TABLE IF EXISTS `purchases_details_tmp`;
CREATE TABLE `purchases_details_tmp` (
  `purchase_detail_id` int(11) NOT NULL,
  `purchase_id` int(11) NOT NULL,
  `purchase_date` date NOT NULL,
  `item_type` float NOT NULL,
  `item_id` int(11) NOT NULL,
  `purchase_qty` bigint(11) NOT NULL,
  `purchase_price` bigint(11) NOT NULL,
  `purchase_total` float NOT NULL,
  `unit_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `purchases_details_tmp`
--

TRUNCATE TABLE `purchases_details_tmp`;