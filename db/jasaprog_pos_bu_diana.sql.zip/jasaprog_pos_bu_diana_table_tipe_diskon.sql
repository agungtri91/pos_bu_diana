
-- --------------------------------------------------------

--
-- Table structure for table `tipe_diskon`
--

DROP TABLE IF EXISTS `tipe_diskon`;
CREATE TABLE `tipe_diskon` (
  `tipe_diskon_id` int(11) NOT NULL,
  `tipe_diskon_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `tipe_diskon`
--

TRUNCATE TABLE `tipe_diskon`;
--
-- Dumping data for table `tipe_diskon`
--

INSERT INTO `tipe_diskon` (`tipe_diskon_id`, `tipe_diskon_name`) VALUES
(1, 'Disk. Memotong / Invoice'),
(2, 'Disk. Memotong / Item');
