
-- --------------------------------------------------------

--
-- Table structure for table `denda`
--

DROP TABLE IF EXISTS `denda`;
CREATE TABLE `denda` (
  `denda_id` int(11) NOT NULL,
  `denda_name` varchar(200) NOT NULL,
  `jenis_denda` int(11) NOT NULL,
  `denda_nominal` bigint(20) NOT NULL,
  `denda_persen` float NOT NULL,
  `denda_desc` text NOT NULL,
  `branch_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `denda`
--

TRUNCATE TABLE `denda`;
--
-- Dumping data for table `denda`
--

INSERT INTO `denda` (`denda_id`, `denda_name`, `jenis_denda`, `denda_nominal`, `denda_persen`, `denda_desc`, `branch_id`) VALUES
(1, 'Harian', 1, 0, 0, '1\r\n', 3),
(2, 'Mingguan', 2, 0, 0, '', 3),
(3, 'Bulanan', 3, 0, 0.5, '', 3);
