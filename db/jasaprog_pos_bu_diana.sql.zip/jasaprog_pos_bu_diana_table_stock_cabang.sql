
-- --------------------------------------------------------

--
-- Table structure for table `stock_cabang`
--

DROP TABLE IF EXISTS `stock_cabang`;
CREATE TABLE `stock_cabang` (
  `id_cabang_item` int(10) UNSIGNED NOT NULL,
  `cabang_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `item_qty` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `stock_cabang`
--

TRUNCATE TABLE `stock_cabang`;