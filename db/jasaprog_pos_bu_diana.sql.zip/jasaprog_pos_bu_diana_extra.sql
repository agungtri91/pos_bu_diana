
--
-- Indexes for dumped tables
--

--
-- Indexes for table `angsuran_kredit`
--
ALTER TABLE `angsuran_kredit`
  ADD PRIMARY KEY (`angsuran_kredit_id`);

--
-- Indexes for table `angsuran_kredit_details`
--
ALTER TABLE `angsuran_kredit_details`
  ADD PRIMARY KEY (`angsuran_kredit_details_id`,`angsuran_nominal`);

--
-- Indexes for table `angsuran_kredit_details_tmp`
--
ALTER TABLE `angsuran_kredit_details_tmp`
  ADD PRIMARY KEY (`angsuran_kredit_details_id`);

--
-- Indexes for table `angsuran_kredit_tmp`
--
ALTER TABLE `angsuran_kredit_tmp`
  ADD PRIMARY KEY (`angsuran_kredit_id`);

--
-- Indexes for table `banks`
--
ALTER TABLE `banks`
  ADD PRIMARY KEY (`bank_id`);

--
-- Indexes for table `branches`
--
ALTER TABLE `branches`
  ADD PRIMARY KEY (`branch_id`);

--
-- Indexes for table `bulan`
--
ALTER TABLE `bulan`
  ADD PRIMARY KEY (`bulan_id`);

--
-- Indexes for table `denda`
--
ALTER TABLE `denda`
  ADD PRIMARY KEY (`denda_id`);

--
-- Indexes for table `gadai`
--
ALTER TABLE `gadai`
  ADD PRIMARY KEY (`gadai_id`);

--
-- Indexes for table `gadai_details`
--
ALTER TABLE `gadai_details`
  ADD PRIMARY KEY (`gadai_detail_id`);

--
-- Indexes for table `gadai_tmp_details`
--
ALTER TABLE `gadai_tmp_details`
  ADD PRIMARY KEY (`gadai_detail_id`);

--
-- Indexes for table `gudang`
--
ALTER TABLE `gudang`
  ADD PRIMARY KEY (`item_gudang_id`);

--
-- Indexes for table `gudang_identitas`
--
ALTER TABLE `gudang_identitas`
  ADD PRIMARY KEY (`gudang_id`);

--
-- Indexes for table `hapus_purchase`
--
ALTER TABLE `hapus_purchase`
  ADD PRIMARY KEY (`hapus_id`);

--
-- Indexes for table `hapus_purchase_details`
--
ALTER TABLE `hapus_purchase_details`
  ADD PRIMARY KEY (`purchase_detail_id`);

--
-- Indexes for table `hapus_transactions`
--
ALTER TABLE `hapus_transactions`
  ADD PRIMARY KEY (`hapus_id`);

--
-- Indexes for table `hapus_transaction_details`
--
ALTER TABLE `hapus_transaction_details`
  ADD PRIMARY KEY (`transaction_detail_id`);

--
-- Indexes for table `hutang`
--
ALTER TABLE `hutang`
  ADD PRIMARY KEY (`hutang_id`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`item_id`);

--
-- Indexes for table `items_types`
--
ALTER TABLE `items_types`
  ADD PRIMARY KEY (`item_type_id`);

--
-- Indexes for table `item_details`
--
ALTER TABLE `item_details`
  ADD PRIMARY KEY (`item_detail_id`,`item_tipe`);

--
-- Indexes for table `item_harga`
--
ALTER TABLE `item_harga`
  ADD PRIMARY KEY (`stock_id`);

--
-- Indexes for table `item_keterangan_details`
--
ALTER TABLE `item_keterangan_details`
  ADD KEY `item_keterangan_details_id` (`item_keterangan_details_id`);

--
-- Indexes for table `item_keterangan_details_tmp`
--
ALTER TABLE `item_keterangan_details_tmp`
  ADD PRIMARY KEY (`item_keterangan_details_id`);

--
-- Indexes for table `item_stocks`
--
ALTER TABLE `item_stocks`
  ADD PRIMARY KEY (`item_stock_id`);

--
-- Indexes for table `item_tmp`
--
ALTER TABLE `item_tmp`
  ADD PRIMARY KEY (`id_item_tmp`);

--
-- Indexes for table `jenis_pembeli`
--
ALTER TABLE `jenis_pembeli`
  ADD PRIMARY KEY (`jenis_pembeli_id`);

--
-- Indexes for table `journals`
--
ALTER TABLE `journals`
  ADD PRIMARY KEY (`journal_id`);

--
-- Indexes for table `journal_types`
--
ALTER TABLE `journal_types`
  ADD PRIMARY KEY (`journal_type_id`);

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`kategori_id`);

--
-- Indexes for table `kategori_keterangan`
--
ALTER TABLE `kategori_keterangan`
  ADD PRIMARY KEY (`kategori_keterangan_id`);

--
-- Indexes for table `kategori_utama`
--
ALTER TABLE `kategori_utama`
  ADD PRIMARY KEY (`id_kategori_utama`);

--
-- Indexes for table `kredit`
--
ALTER TABLE `kredit`
  ADD PRIMARY KEY (`kredit_id`);

--
-- Indexes for table `lama_angsuran`
--
ALTER TABLE `lama_angsuran`
  ADD PRIMARY KEY (`lama_angsuran_id`);

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`member_id`);

--
-- Indexes for table `member_items`
--
ALTER TABLE `member_items`
  ADD PRIMARY KEY (`member_item_id`);

--
-- Indexes for table `mutasi_barang`
--
ALTER TABLE `mutasi_barang`
  ADD PRIMARY KEY (`mutasi_id`);

--
-- Indexes for table `office`
--
ALTER TABLE `office`
  ADD PRIMARY KEY (`office_id`);

--
-- Indexes for table `partners`
--
ALTER TABLE `partners`
  ADD PRIMARY KEY (`partner_id`);

--
-- Indexes for table `payment_methods`
--
ALTER TABLE `payment_methods`
  ADD PRIMARY KEY (`payment_method_id`);

--
-- Indexes for table `pengangsuran_hut`
--
ALTER TABLE `pengangsuran_hut`
  ADD PRIMARY KEY (`id_pengangsuran`);

--
-- Indexes for table `pengangsuran_piutang`
--
ALTER TABLE `pengangsuran_piutang`
  ADD PRIMARY KEY (`id_pengangsuran`);

--
-- Indexes for table `penyesuaian_stock_cabang`
--
ALTER TABLE `penyesuaian_stock_cabang`
  ADD PRIMARY KEY (`penyesuaian_stock_cabang_id`);

--
-- Indexes for table `periode`
--
ALTER TABLE `periode`
  ADD PRIMARY KEY (`periode_id`);

--
-- Indexes for table `permits`
--
ALTER TABLE `permits`
  ADD PRIMARY KEY (`permit_id`);

--
-- Indexes for table `purchases`
--
ALTER TABLE `purchases`
  ADD PRIMARY KEY (`purchases_id`,`bank_account`);

--
-- Indexes for table `purchases_details`
--
ALTER TABLE `purchases_details`
  ADD PRIMARY KEY (`purchase_detail_id`);

--
-- Indexes for table `purchases_details_tmp`
--
ALTER TABLE `purchases_details_tmp`
  ADD PRIMARY KEY (`purchase_detail_id`);

--
-- Indexes for table `purchases_tmp`
--
ALTER TABLE `purchases_tmp`
  ADD PRIMARY KEY (`purchases_id`);

--
-- Indexes for table `retur`
--
ALTER TABLE `retur`
  ADD PRIMARY KEY (`retur_id`);

--
-- Indexes for table `retur_details`
--
ALTER TABLE `retur_details`
  ADD PRIMARY KEY (`retur_details_id`);

--
-- Indexes for table `retur_details_pembelian_tmp`
--
ALTER TABLE `retur_details_pembelian_tmp`
  ADD PRIMARY KEY (`retur_details_id`);

--
-- Indexes for table `retur_details_tmp`
--
ALTER TABLE `retur_details_tmp`
  ADD PRIMARY KEY (`retur_details_id`);

--
-- Indexes for table `retur_detail_item`
--
ALTER TABLE `retur_detail_item`
  ADD PRIMARY KEY (`retur_detail_item_id`);

--
-- Indexes for table `retur_pembelian`
--
ALTER TABLE `retur_pembelian`
  ADD PRIMARY KEY (`retur_id`);

--
-- Indexes for table `retur_pembelian_details`
--
ALTER TABLE `retur_pembelian_details`
  ADD PRIMARY KEY (`retur_details_id`);

--
-- Indexes for table `retur_pembelian_details_item`
--
ALTER TABLE `retur_pembelian_details_item`
  ADD PRIMARY KEY (`retur_pembelian_details_item_id`);

--
-- Indexes for table `retur_pembelian_tmp`
--
ALTER TABLE `retur_pembelian_tmp`
  ADD PRIMARY KEY (`retur_id`);

--
-- Indexes for table `retur_tmp`
--
ALTER TABLE `retur_tmp`
  ADD PRIMARY KEY (`retur_id`);

--
-- Indexes for table `retur_widget_details_tmp`
--
ALTER TABLE `retur_widget_details_tmp`
  ADD PRIMARY KEY (`retur_widget_details_tmp_id`);

--
-- Indexes for table `retur_widget_tmp`
--
ALTER TABLE `retur_widget_tmp`
  ADD PRIMARY KEY (`retur_tmp_id`);

--
-- Indexes for table `side_menus`
--
ALTER TABLE `side_menus`
  ADD PRIMARY KEY (`side_menu_id`);

--
-- Indexes for table `stock_cabang`
--
ALTER TABLE `stock_cabang`
  ADD PRIMARY KEY (`id_cabang_item`);

--
-- Indexes for table `stock_retur_details_pembelian`
--
ALTER TABLE `stock_retur_details_pembelian`
  ADD PRIMARY KEY (`item_stock_detail_id`);

--
-- Indexes for table `stock_retur_details_penjualan`
--
ALTER TABLE `stock_retur_details_penjualan`
  ADD PRIMARY KEY (`item_stock_detail_id`);

--
-- Indexes for table `stock_retur_pembelian`
--
ALTER TABLE `stock_retur_pembelian`
  ADD PRIMARY KEY (`item_stock_retur_id`);

--
-- Indexes for table `stock_retur_penjualan`
--
ALTER TABLE `stock_retur_penjualan`
  ADD PRIMARY KEY (`item_stock_retur_id`);

--
-- Indexes for table `sub_kategori`
--
ALTER TABLE `sub_kategori`
  ADD PRIMARY KEY (`sub_kategori_id`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`supplier_id`);

--
-- Indexes for table `tipe_diskon`
--
ALTER TABLE `tipe_diskon`
  ADD PRIMARY KEY (`tipe_diskon_id`);

--
-- Indexes for table `tipe_pembeli_diskon`
--
ALTER TABLE `tipe_pembeli_diskon`
  ADD PRIMARY KEY (`tipe_pembeli_diskon_id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`transaction_id`,`transaction_change`);

--
-- Indexes for table `transactions_tmp`
--
ALTER TABLE `transactions_tmp`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `transaction_details`
--
ALTER TABLE `transaction_details`
  ADD PRIMARY KEY (`transaction_detail_id`);

--
-- Indexes for table `transaction_details_item`
--
ALTER TABLE `transaction_details_item`
  ADD PRIMARY KEY (`transaction_details_item`);

--
-- Indexes for table `transaction_histories`
--
ALTER TABLE `transaction_histories`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `transaction_new_tmp`
--
ALTER TABLE `transaction_new_tmp`
  ADD PRIMARY KEY (`tnt_id`);

--
-- Indexes for table `transaction_order_types`
--
ALTER TABLE `transaction_order_types`
  ADD PRIMARY KEY (`tot_id`);

--
-- Indexes for table `transaction_tmp_details`
--
ALTER TABLE `transaction_tmp_details`
  ADD PRIMARY KEY (`transaction_detail_id`);

--
-- Indexes for table `type_pembeli`
--
ALTER TABLE `type_pembeli`
  ADD PRIMARY KEY (`type_id_pembeli`);

--
-- Indexes for table `uang_kasir`
--
ALTER TABLE `uang_kasir`
  ADD PRIMARY KEY (`uang_kasir_id`);

--
-- Indexes for table `units`
--
ALTER TABLE `units`
  ADD PRIMARY KEY (`unit_id`);

--
-- Indexes for table `unit_konversi`
--
ALTER TABLE `unit_konversi`
  ADD PRIMARY KEY (`unit_konversi_id`);

--
-- Indexes for table `unit_konversi_tmp`
--
ALTER TABLE `unit_konversi_tmp`
  ADD PRIMARY KEY (`unit_konversi_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `user_types`
--
ALTER TABLE `user_types`
  ADD PRIMARY KEY (`user_type_id`);

--
-- Indexes for table `user_typesz`
--
ALTER TABLE `user_typesz`
  ADD PRIMARY KEY (`user_type_id`);

--
-- Indexes for table `widget_tmp`
--
ALTER TABLE `widget_tmp`
  ADD PRIMARY KEY (`wt_id`);

--
-- Indexes for table `widget_tmp_details`
--
ALTER TABLE `widget_tmp_details`
  ADD PRIMARY KEY (`wtd_id`);

--
-- Indexes for table `wr_pembelian_details_tmp`
--
ALTER TABLE `wr_pembelian_details_tmp`
  ADD PRIMARY KEY (`wr_pembelian_details_id`);

--
-- Indexes for table `wr_pembelian_tmp`
--
ALTER TABLE `wr_pembelian_tmp`
  ADD PRIMARY KEY (`retur_tmp_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `angsuran_kredit`
--
ALTER TABLE `angsuran_kredit`
  MODIFY `angsuran_kredit_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `angsuran_kredit_details`
--
ALTER TABLE `angsuran_kredit_details`
  MODIFY `angsuran_kredit_details_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `angsuran_kredit_details_tmp`
--
ALTER TABLE `angsuran_kredit_details_tmp`
  MODIFY `angsuran_kredit_details_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `angsuran_kredit_tmp`
--
ALTER TABLE `angsuran_kredit_tmp`
  MODIFY `angsuran_kredit_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `banks`
--
ALTER TABLE `banks`
  MODIFY `bank_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `branches`
--
ALTER TABLE `branches`
  MODIFY `branch_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `bulan`
--
ALTER TABLE `bulan`
  MODIFY `bulan_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `denda`
--
ALTER TABLE `denda`
  MODIFY `denda_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `gadai`
--
ALTER TABLE `gadai`
  MODIFY `gadai_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `gadai_details`
--
ALTER TABLE `gadai_details`
  MODIFY `gadai_detail_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `gadai_tmp_details`
--
ALTER TABLE `gadai_tmp_details`
  MODIFY `gadai_detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `gudang`
--
ALTER TABLE `gudang`
  MODIFY `item_gudang_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `gudang_identitas`
--
ALTER TABLE `gudang_identitas`
  MODIFY `gudang_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `hapus_purchase`
--
ALTER TABLE `hapus_purchase`
  MODIFY `hapus_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `hapus_purchase_details`
--
ALTER TABLE `hapus_purchase_details`
  MODIFY `purchase_detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `hapus_transactions`
--
ALTER TABLE `hapus_transactions`
  MODIFY `hapus_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `hapus_transaction_details`
--
ALTER TABLE `hapus_transaction_details`
  MODIFY `transaction_detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `hutang`
--
ALTER TABLE `hutang`
  MODIFY `hutang_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;
--
-- AUTO_INCREMENT for table `items_types`
--
ALTER TABLE `items_types`
  MODIFY `item_type_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `item_details`
--
ALTER TABLE `item_details`
  MODIFY `item_detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;
--
-- AUTO_INCREMENT for table `item_harga`
--
ALTER TABLE `item_harga`
  MODIFY `stock_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT for table `item_keterangan_details`
--
ALTER TABLE `item_keterangan_details`
  MODIFY `item_keterangan_details_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `item_keterangan_details_tmp`
--
ALTER TABLE `item_keterangan_details_tmp`
  MODIFY `item_keterangan_details_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `item_stocks`
--
ALTER TABLE `item_stocks`
  MODIFY `item_stock_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `item_tmp`
--
ALTER TABLE `item_tmp`
  MODIFY `id_item_tmp` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `jenis_pembeli`
--
ALTER TABLE `jenis_pembeli`
  MODIFY `jenis_pembeli_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `journals`
--
ALTER TABLE `journals`
  MODIFY `journal_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=117;
--
-- AUTO_INCREMENT for table `journal_types`
--
ALTER TABLE `journal_types`
  MODIFY `journal_type_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `kategori`
--
ALTER TABLE `kategori`
  MODIFY `kategori_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `kategori_keterangan`
--
ALTER TABLE `kategori_keterangan`
  MODIFY `kategori_keterangan_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `kredit`
--
ALTER TABLE `kredit`
  MODIFY `kredit_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `lama_angsuran`
--
ALTER TABLE `lama_angsuran`
  MODIFY `lama_angsuran_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
  MODIFY `member_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
--
-- AUTO_INCREMENT for table `member_items`
--
ALTER TABLE `member_items`
  MODIFY `member_item_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `mutasi_barang`
--
ALTER TABLE `mutasi_barang`
  MODIFY `mutasi_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `partners`
--
ALTER TABLE `partners`
  MODIFY `partner_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `payment_methods`
--
ALTER TABLE `payment_methods`
  MODIFY `payment_method_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `pengangsuran_hut`
--
ALTER TABLE `pengangsuran_hut`
  MODIFY `id_pengangsuran` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `pengangsuran_piutang`
--
ALTER TABLE `pengangsuran_piutang`
  MODIFY `id_pengangsuran` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `penyesuaian_stock_cabang`
--
ALTER TABLE `penyesuaian_stock_cabang`
  MODIFY `penyesuaian_stock_cabang_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `periode`
--
ALTER TABLE `periode`
  MODIFY `periode_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `permits`
--
ALTER TABLE `permits`
  MODIFY `permit_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2823;
--
-- AUTO_INCREMENT for table `purchases`
--
ALTER TABLE `purchases`
  MODIFY `purchases_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `purchases_details`
--
ALTER TABLE `purchases_details`
  MODIFY `purchase_detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `purchases_details_tmp`
--
ALTER TABLE `purchases_details_tmp`
  MODIFY `purchase_detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT for table `retur`
--
ALTER TABLE `retur`
  MODIFY `retur_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `retur_details`
--
ALTER TABLE `retur_details`
  MODIFY `retur_details_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `retur_details_pembelian_tmp`
--
ALTER TABLE `retur_details_pembelian_tmp`
  MODIFY `retur_details_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `retur_details_tmp`
--
ALTER TABLE `retur_details_tmp`
  MODIFY `retur_details_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `retur_detail_item`
--
ALTER TABLE `retur_detail_item`
  MODIFY `retur_detail_item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `retur_pembelian`
--
ALTER TABLE `retur_pembelian`
  MODIFY `retur_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `retur_pembelian_details`
--
ALTER TABLE `retur_pembelian_details`
  MODIFY `retur_details_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `retur_pembelian_details_item`
--
ALTER TABLE `retur_pembelian_details_item`
  MODIFY `retur_pembelian_details_item_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `retur_pembelian_tmp`
--
ALTER TABLE `retur_pembelian_tmp`
  MODIFY `retur_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `retur_tmp`
--
ALTER TABLE `retur_tmp`
  MODIFY `retur_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `retur_widget_details_tmp`
--
ALTER TABLE `retur_widget_details_tmp`
  MODIFY `retur_widget_details_tmp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `retur_widget_tmp`
--
ALTER TABLE `retur_widget_tmp`
  MODIFY `retur_tmp_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `side_menus`
--
ALTER TABLE `side_menus`
  MODIFY `side_menu_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;
--
-- AUTO_INCREMENT for table `stock_retur_details_pembelian`
--
ALTER TABLE `stock_retur_details_pembelian`
  MODIFY `item_stock_detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `stock_retur_details_penjualan`
--
ALTER TABLE `stock_retur_details_penjualan`
  MODIFY `item_stock_detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `stock_retur_pembelian`
--
ALTER TABLE `stock_retur_pembelian`
  MODIFY `item_stock_retur_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `stock_retur_penjualan`
--
ALTER TABLE `stock_retur_penjualan`
  MODIFY `item_stock_retur_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `sub_kategori`
--
ALTER TABLE `sub_kategori`
  MODIFY `sub_kategori_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `supplier_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `tipe_diskon`
--
ALTER TABLE `tipe_diskon`
  MODIFY `tipe_diskon_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tipe_pembeli_diskon`
--
ALTER TABLE `tipe_pembeli_diskon`
  MODIFY `tipe_pembeli_diskon_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `transaction_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `transactions_tmp`
--
ALTER TABLE `transactions_tmp`
  MODIFY `transaction_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `transaction_details`
--
ALTER TABLE `transaction_details`
  MODIFY `transaction_detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `transaction_details_item`
--
ALTER TABLE `transaction_details_item`
  MODIFY `transaction_details_item` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `transaction_new_tmp`
--
ALTER TABLE `transaction_new_tmp`
  MODIFY `tnt_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `transaction_order_types`
--
ALTER TABLE `transaction_order_types`
  MODIFY `tot_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `transaction_tmp_details`
--
ALTER TABLE `transaction_tmp_details`
  MODIFY `transaction_detail_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `type_pembeli`
--
ALTER TABLE `type_pembeli`
  MODIFY `type_id_pembeli` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `uang_kasir`
--
ALTER TABLE `uang_kasir`
  MODIFY `uang_kasir_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;
--
-- AUTO_INCREMENT for table `units`
--
ALTER TABLE `units`
  MODIFY `unit_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `unit_konversi`
--
ALTER TABLE `unit_konversi`
  MODIFY `unit_konversi_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;
--
-- AUTO_INCREMENT for table `unit_konversi_tmp`
--
ALTER TABLE `unit_konversi_tmp`
  MODIFY `unit_konversi_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `user_types`
--
ALTER TABLE `user_types`
  MODIFY `user_type_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `user_typesz`
--
ALTER TABLE `user_typesz`
  MODIFY `user_type_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `widget_tmp`
--
ALTER TABLE `widget_tmp`
  MODIFY `wt_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;
--
-- AUTO_INCREMENT for table `widget_tmp_details`
--
ALTER TABLE `widget_tmp_details`
  MODIFY `wtd_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `wr_pembelian_details_tmp`
--
ALTER TABLE `wr_pembelian_details_tmp`
  MODIFY `wr_pembelian_details_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `wr_pembelian_tmp`
--
ALTER TABLE `wr_pembelian_tmp`
  MODIFY `retur_tmp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;