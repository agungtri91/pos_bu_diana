
-- --------------------------------------------------------

--
-- Table structure for table `members`
--

DROP TABLE IF EXISTS `members`;
CREATE TABLE `members` (
  `member_id` int(11) NOT NULL,
  `member_name` varchar(100) NOT NULL,
  `member_phone` varchar(100) NOT NULL,
  `member_email` varchar(200) NOT NULL,
  `member_alamat` varchar(200) NOT NULL,
  `member_discount` int(11) NOT NULL,
  `tipe_pembeli` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `members`
--

TRUNCATE TABLE `members`;
--
-- Dumping data for table `members`
--

INSERT INTO `members` (`member_id`, `member_name`, `member_phone`, `member_email`, `member_alamat`, `member_discount`, `tipe_pembeli`) VALUES
(30, 'Firman Zain', '081-2428649832', 'firman@gmail', 'Ponorogo', 0, 15),
(31, 'Lintang', '2134567', 'lintang@gmail.com', 'Lintang Utara 25', 0, 14),
(32, 'Ricad', '12', '12', '12', 0, 0),
(34, 'Agung', '48938403', 'agung@gmail.com', 'Rungkut', 0, 0);
