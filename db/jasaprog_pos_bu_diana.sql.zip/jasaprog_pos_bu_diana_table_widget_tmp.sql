
-- --------------------------------------------------------

--
-- Table structure for table `widget_tmp`
--

DROP TABLE IF EXISTS `widget_tmp`;
CREATE TABLE `widget_tmp` (
  `wt_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `stock_id` int(11) NOT NULL,
  `jumlah` float NOT NULL,
  `jumlah_konversi` float NOT NULL,
  `unit_id` int(11) NOT NULL,
  `transaction_id` int(11) NOT NULL,
  `wt_desc` text NOT NULL,
  `zak` int(11) NOT NULL,
  `printed` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `widget_tmp`
--

TRUNCATE TABLE `widget_tmp`;
--
-- Dumping data for table `widget_tmp`
--

INSERT INTO `widget_tmp` (`wt_id`, `user_id`, `stock_id`, `jumlah`, `jumlah_konversi`, `unit_id`, `transaction_id`, `wt_desc`, `zak`, `printed`) VALUES
(57, 1, 0, 0, 0, 0, 0, '', 0, 0),
(75, 1, 1, 1, 1, 14, 17, '', 0, 0);
