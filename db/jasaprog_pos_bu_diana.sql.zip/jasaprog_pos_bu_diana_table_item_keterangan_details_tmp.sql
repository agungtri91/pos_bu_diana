
-- --------------------------------------------------------

--
-- Table structure for table `item_keterangan_details_tmp`
--

DROP TABLE IF EXISTS `item_keterangan_details_tmp`;
CREATE TABLE `item_keterangan_details_tmp` (
  `item_keterangan_details_id` int(11) NOT NULL,
  `purchase_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `kategori_id` int(11) NOT NULL,
  `kategori_keterangan_id` int(11) NOT NULL,
  `keterangan_details` varchar(200) NOT NULL,
  `supplier` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `item_keterangan_details_tmp`
--

TRUNCATE TABLE `item_keterangan_details_tmp`;