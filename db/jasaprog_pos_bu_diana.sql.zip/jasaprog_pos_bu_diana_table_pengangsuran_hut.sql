
-- --------------------------------------------------------

--
-- Table structure for table `pengangsuran_hut`
--

DROP TABLE IF EXISTS `pengangsuran_hut`;
CREATE TABLE `pengangsuran_hut` (
  `id_pengangsuran` int(11) NOT NULL,
  `purchase_id` int(11) NOT NULL,
  `id_hutang` int(11) NOT NULL,
  `jml_bayar` bigint(11) NOT NULL,
  `payment_method` int(11) NOT NULL,
  `bank1` int(11) NOT NULL,
  `no_bank_id_1` int(11) NOT NULL,
  `bank2` int(11) NOT NULL,
  `no_bank_id_2` int(11) NOT NULL,
  `angsuran_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `pengangsuran_hut`
--

TRUNCATE TABLE `pengangsuran_hut`;
--
-- Dumping data for table `pengangsuran_hut`
--

INSERT INTO `pengangsuran_hut` (`id_pengangsuran`, `purchase_id`, `id_hutang`, `jml_bayar`, `payment_method`, `bank1`, `no_bank_id_1`, `bank2`, `no_bank_id_2`, `angsuran_date`) VALUES
(1, 3, 2, 800000, 1, 0, 0, 0, 0, '2017-01-12 01:35:35');
