
-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

DROP TABLE IF EXISTS `kategori`;
CREATE TABLE `kategori` (
  `kategori_id` int(11) NOT NULL,
  `kategori_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `kategori`
--

TRUNCATE TABLE `kategori`;
--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`kategori_id`, `kategori_name`) VALUES
(6, 'LAMPU LED'),
(7, 'Sepeda Motor'),
(8, 'Mobil'),
(9, 'Lemari'),
(10, 'HD'),
(11, 'HD'),
(12, 'LAPTOP');
