
-- --------------------------------------------------------

--
-- Table structure for table `sub_kategori`
--

DROP TABLE IF EXISTS `sub_kategori`;
CREATE TABLE `sub_kategori` (
  `sub_kategori_id` int(11) NOT NULL,
  `sub_kategori_name` varchar(100) NOT NULL,
  `kategori_utama_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `sub_kategori`
--

TRUNCATE TABLE `sub_kategori`;
--
-- Dumping data for table `sub_kategori`
--

INSERT INTO `sub_kategori` (`sub_kategori_id`, `sub_kategori_name`, `kategori_utama_id`) VALUES
(17, 'Android', 6),
(20, 'Bebek', 7),
(21, 'Matic', 7),
(22, 'Sport', 7),
(24, 'Sedan', 8),
(25, 'Pick Up', 8),
(26, 'Kayu', 9),
(27, 'i os', 6);
