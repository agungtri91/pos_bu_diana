
-- --------------------------------------------------------

--
-- Table structure for table `retur_pembelian`
--

DROP TABLE IF EXISTS `retur_pembelian`;
CREATE TABLE `retur_pembelian` (
  `retur_id` int(11) NOT NULL,
  `purchase_id` int(11) NOT NULL,
  `purchase_date` date NOT NULL,
  `retur_date` date NOT NULL,
  `payment_method` int(11) NOT NULL,
  `bank_id_1` int(11) NOT NULL,
  `bank_account_1` int(11) NOT NULL,
  `bank_id_2` int(11) NOT NULL,
  `bank_account_2` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `retur_total_price` bigint(11) NOT NULL,
  `lunas` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `retur_pembelian`
--

TRUNCATE TABLE `retur_pembelian`;
--
-- Dumping data for table `retur_pembelian`
--

INSERT INTO `retur_pembelian` (`retur_id`, `purchase_id`, `purchase_date`, `retur_date`, `payment_method`, `bank_id_1`, `bank_account_1`, `bank_id_2`, `bank_account_2`, `user_id`, `retur_total_price`, `lunas`) VALUES
(1, 3, '2017-01-17', '2017-01-18', 1, 0, 0, 0, 0, 1, 12, 1),
(2, 2, '2017-03-04', '2017-03-05', 1, 0, 0, 0, 0, 1, 1200, 0);
