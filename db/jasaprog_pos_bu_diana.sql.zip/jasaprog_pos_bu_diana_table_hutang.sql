
-- --------------------------------------------------------

--
-- Table structure for table `hutang`
--

DROP TABLE IF EXISTS `hutang`;
CREATE TABLE `hutang` (
  `hutang_id` int(11) NOT NULL,
  `purchase_id` int(11) NOT NULL,
  `purchase_date` date NOT NULL,
  `batas_tanggal_angsuran` date NOT NULL,
  `hutang_code` varchar(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `uang_muka_barang` bigint(20) NOT NULL,
  `payment_method_id` int(11) NOT NULL,
  `bank_id_angsuran` int(11) NOT NULL,
  `bank_account_angsuran` varchar(200) NOT NULL,
  `bank_id_to_angsuran` int(11) NOT NULL,
  `bank_account_to_angsuran` varchar(200) NOT NULL,
  `lunas` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `hutang`
--

TRUNCATE TABLE `hutang`;
--
-- Dumping data for table `hutang`
--

INSERT INTO `hutang` (`hutang_id`, `purchase_id`, `purchase_date`, `batas_tanggal_angsuran`, `hutang_code`, `user_id`, `supplier_id`, `uang_muka_barang`, `payment_method_id`, `bank_id_angsuran`, `bank_account_angsuran`, `bank_id_to_angsuran`, `bank_account_to_angsuran`, `lunas`) VALUES
(1, 6, '2017-03-11', '0000-00-00', '51489208189', 1, 0, 500000, 0, 0, '', 0, '', 0),
(7, 7, '2017-03-11', '0000-00-00', '51489209293', 1, 6, 2400000, 0, 0, '', 0, '', 0),
(8, 7, '2017-03-11', '0000-00-00', '51489209326', 1, 6, 2400000, 0, 0, '', 0, '', 0),
(9, 8, '2017-03-11', '0000-00-00', '51489212430', 1, 1, 1200000, 0, 0, '', 0, '', 0),
(10, 9, '2017-05-28', '0000-00-00', '51496002577', 1, 4, 1200000, 0, 0, '', 0, '', 0),
(11, 9, '2017-05-28', '0000-00-00', '51496002709', 1, 4, 1200000, 0, 0, '', 0, '', 0);
