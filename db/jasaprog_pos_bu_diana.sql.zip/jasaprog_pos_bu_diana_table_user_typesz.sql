
-- --------------------------------------------------------

--
-- Table structure for table `user_typesz`
--

DROP TABLE IF EXISTS `user_typesz`;
CREATE TABLE `user_typesz` (
  `user_type_id` int(11) NOT NULL,
  `user_type_name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `user_typesz`
--

TRUNCATE TABLE `user_typesz`;