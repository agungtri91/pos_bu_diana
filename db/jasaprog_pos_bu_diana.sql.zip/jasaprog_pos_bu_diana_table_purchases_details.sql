
-- --------------------------------------------------------

--
-- Table structure for table `purchases_details`
--

DROP TABLE IF EXISTS `purchases_details`;
CREATE TABLE `purchases_details` (
  `purchase_detail_id` int(11) NOT NULL,
  `purchase_id` int(11) NOT NULL,
  `purchase_date` date NOT NULL,
  `item_id` int(11) NOT NULL,
  `purchase_qty` float NOT NULL,
  `purchase_price` bigint(11) NOT NULL,
  `purchase_total` bigint(11) NOT NULL,
  `retur` float NOT NULL,
  `unit_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `purchases_details`
--

TRUNCATE TABLE `purchases_details`;
--
-- Dumping data for table `purchases_details`
--

INSERT INTO `purchases_details` (`purchase_detail_id`, `purchase_id`, `purchase_date`, `item_id`, `purchase_qty`, `purchase_price`, `purchase_total`, `retur`, `unit_id`) VALUES
(1, 6, '2017-03-11', 1, 1, 1200000, 1200000, 0, 14),
(2, 9, '2017-05-28', 1, 10, 120000, 1200000, 0, 14);
