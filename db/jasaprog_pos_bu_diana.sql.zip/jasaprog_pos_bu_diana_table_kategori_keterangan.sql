
-- --------------------------------------------------------

--
-- Table structure for table `kategori_keterangan`
--

DROP TABLE IF EXISTS `kategori_keterangan`;
CREATE TABLE `kategori_keterangan` (
  `kategori_keterangan_id` int(11) NOT NULL,
  `kategori_id` int(11) NOT NULL,
  `kategori_keterangan_name` varchar(200) NOT NULL,
  `keterangan` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `kategori_keterangan`
--

TRUNCATE TABLE `kategori_keterangan`;
--
-- Dumping data for table `kategori_keterangan`
--

INSERT INTO `kategori_keterangan` (`kategori_keterangan_id`, `kategori_id`, `kategori_keterangan_name`, `keterangan`) VALUES
(4, 6, 'IMEI', ''),
(5, 6, 'S/N', ''),
(13, 6, 'no. Baterai', '');
