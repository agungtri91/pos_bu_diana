
-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
CREATE TABLE `transactions` (
  `transaction_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `partner_id` int(11) NOT NULL,
  `transaction_date` datetime NOT NULL,
  `transaction_total` bigint(11) NOT NULL,
  `transaction_discount` float NOT NULL,
  `total_discount_persen` bigint(20) NOT NULL,
  `transaction_discount_nominal` bigint(20) NOT NULL,
  `transaction_grand_total` bigint(11) NOT NULL,
  `transaction_payment` bigint(11) NOT NULL,
  `transaction_change` bigint(11) NOT NULL,
  `payment_method_id` int(11) NOT NULL,
  `bank_id` int(11) NOT NULL,
  `i_bank_account` int(11) NOT NULL,
  `bank_id_to` int(11) NOT NULL,
  `i_bank_account_to` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `transaction_code` int(11) NOT NULL,
  `tax` bigint(11) NOT NULL,
  `total_all` bigint(11) NOT NULL,
  `transaction_desc` text NOT NULL,
  `lunas` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `transactions`
--

TRUNCATE TABLE `transactions`;
--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`transaction_id`, `member_id`, `partner_id`, `transaction_date`, `transaction_total`, `transaction_discount`, `total_discount_persen`, `transaction_discount_nominal`, `transaction_grand_total`, `transaction_payment`, `transaction_change`, `payment_method_id`, `bank_id`, `i_bank_account`, `bank_id_to`, `i_bank_account_to`, `user_id`, `transaction_code`, `tax`, `total_all`, `transaction_desc`, `lunas`, `branch_id`) VALUES
(2, 34, 0, '2017-03-09 09:25:03', 1300000, 0, 0, 0, 1300000, 1300000, 0, 5, 0, 0, 0, 0, 1, 1489047903, 0, 1300000, '', 0, 3),
(3, 0, 0, '0000-00-00 00:00:00', 1300000, 0, 0, 0, 1300000, 1300000, 0, 5, 0, 0, 0, 0, 1, 0, 0, 1300000, '', 0, 0),
(4, 30, 0, '2017-03-09 09:56:54', 1300000, 156, 0, 0, 1144000, 1144000, 0, 5, 0, 0, 0, 0, 1, 1489049814, 0, 1144000, '', 0, 3),
(5, 31, 0, '2017-03-11 07:14:11', 1300000, 0, 0, 0, 1300000, 600000, 0, 5, 0, 0, 0, 0, 1, 1489212851, 0, 1300000, '', 0, 3),
(6, 34, 0, '2017-03-11 07:32:35', 258000, 0, 0, 0, 258000, 58000, 0, 5, 0, 0, 0, 0, 1, 1489213955, 0, 258000, '', 1, 3),
(7, 30, 0, '2017-03-11 07:33:47', 2600000, 312, 0, 0, 2288000, 200000, 0, 5, 0, 0, 0, 0, 1, 1489214027, 0, 2288000, '', 1, 3),
(8, 0, 0, '0000-00-00 00:00:00', 2600000, 312, 0, 0, 2288000, 200000, 0, 5, 0, 0, 0, 0, 1, 0, 0, 2288000, '', 1, 0),
(9, 30, 0, '2017-05-07 20:59:54', 1300000, 156, 0, 0, 1144000, 800000, 0, 5, 0, 0, 0, 0, 1, 1494183594, 0, 1144000, '', 1, 3),
(10, 31, 0, '2017-05-28 21:52:30', 130000000, 0, 0, 0, 130000000, 130000000, 0, 5, 0, 0, 0, 0, 1, 1496001150, 0, 130000000, '', 1, 3),
(11, 30, 0, '2017-07-25 09:05:32', 2600000, 156, 0, 0, 2444000, 2444000, 0, 1, 0, 0, 0, 0, 1, 1500973532, 0, 2444000, '', 0, 3),
(12, 32, 0, '2017-07-25 09:09:29', 129000, 0, 0, 0, 129000, 129000, 0, 1, 0, 0, 0, 0, 1, 1500973769, 0, 129000, '', 0, 3),
(13, 30, 0, '2017-07-26 03:12:41', 129000, 15.48, 0, 0, 113520, 120000, 0, 1, 0, 0, 0, 0, 1, 1501038761, 0, 113520, '', 0, 3),
(14, 30, 0, '2017-07-27 09:10:03', 27300000, 3.276, 0, 0, 24024000, 24024000, 0, 5, 0, 0, 0, 0, 1, 1501146603, 0, 24024000, '', 1, 3),
(15, 30, 0, '2017-07-31 04:34:00', 4035500, 16.254, 0, 0, 4019246, 4019246, 0, 5, 0, 0, 0, 0, 1, 1501475640, 0, 4019246, '', 1, 3),
(16, 32, 0, '2017-07-31 06:32:31', 9358000, 0, 0, 0, 9358000, 9358000, 0, 1, 0, 0, 0, 0, 1, 1501482751, 0, 9358000, '', 0, 3);
