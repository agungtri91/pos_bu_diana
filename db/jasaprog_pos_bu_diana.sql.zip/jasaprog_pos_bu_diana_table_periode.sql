
-- --------------------------------------------------------

--
-- Table structure for table `periode`
--

DROP TABLE IF EXISTS `periode`;
CREATE TABLE `periode` (
  `periode_id` int(11) NOT NULL,
  `periode_name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `periode`
--

TRUNCATE TABLE `periode`;
--
-- Dumping data for table `periode`
--

INSERT INTO `periode` (`periode_id`, `periode_name`) VALUES
(1, 'Hari'),
(2, 'Minggu'),
(3, 'Bulan'),
(4, 'Tahun');
