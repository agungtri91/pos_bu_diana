
-- --------------------------------------------------------

--
-- Table structure for table `partners`
--

DROP TABLE IF EXISTS `partners`;
CREATE TABLE `partners` (
  `partner_id` int(11) NOT NULL,
  `partner_name` varchar(200) NOT NULL,
  `partner_alamat` text NOT NULL,
  `partner_phone` varchar(200) NOT NULL,
  `partner_email` varchar(200) NOT NULL,
  `partner_deskripsi` text NOT NULL,
  `branch_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `partners`
--

TRUNCATE TABLE `partners`;
--
-- Dumping data for table `partners`
--

INSERT INTO `partners` (`partner_id`, `partner_name`, `partner_alamat`, `partner_phone`, `partner_email`, `partner_deskripsi`, `branch_id`) VALUES
(6, 'SAMSUL', 'qw@qwewq', 'qw@qwewq', 'qw@qwewq', 'dvdvqvvfvf', 3);
