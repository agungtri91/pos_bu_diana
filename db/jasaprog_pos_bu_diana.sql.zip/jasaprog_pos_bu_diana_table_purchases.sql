
-- --------------------------------------------------------

--
-- Table structure for table `purchases`
--

DROP TABLE IF EXISTS `purchases`;
CREATE TABLE `purchases` (
  `purchases_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `purchases_date` datetime NOT NULL,
  `purchases_code` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `bank_id` int(11) NOT NULL,
  `bank_account` int(11) NOT NULL,
  `bank_id_to` int(11) NOT NULL,
  `bank_account_to` int(11) NOT NULL,
  `payment_method` int(11) NOT NULL,
  `purchase_total` bigint(11) NOT NULL,
  `purchase_payment` bigint(11) NOT NULL,
  `purchase_change` bigint(11) NOT NULL,
  `lunas` int(11) NOT NULL,
  `purchase_desc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `purchases`
--

TRUNCATE TABLE `purchases`;
--
-- Dumping data for table `purchases`
--

INSERT INTO `purchases` (`purchases_id`, `user_id`, `purchases_date`, `purchases_code`, `supplier_id`, `branch_id`, `bank_id`, `bank_account`, `bank_id_to`, `bank_account_to`, `payment_method`, `purchase_total`, `purchase_payment`, `purchase_change`, `lunas`, `purchase_desc`) VALUES
(6, 1, '2017-03-11 05:55:29', 1489208189, 4, 3, 0, 0, 0, 0, 5, 1200000, 500000, 0, 1, ''),
(7, 1, '2017-03-11 06:14:23', 1489209294, 6, 3, 0, 0, 0, 0, 5, 240000000, 2400000, 0, 1, ''),
(8, 1, '2017-03-11 07:07:00', 1489212430, 1, 3, 0, 0, 0, 0, 5, 1200000, 1200000, 0, 1, ''),
(9, 1, '2017-05-28 22:14:36', 1496002577, 4, 3, 0, 0, 0, 0, 5, 1200000, 1200000, 0, 1, '');
