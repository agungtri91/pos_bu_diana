
-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

DROP TABLE IF EXISTS `suppliers`;
CREATE TABLE `suppliers` (
  `supplier_id` int(11) NOT NULL,
  `supplier_name` varchar(50) NOT NULL,
  `supplier_phone` varchar(11) NOT NULL,
  `supplier_email` varchar(100) NOT NULL,
  `supplier_addres` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `suppliers`
--

TRUNCATE TABLE `suppliers`;
--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`supplier_id`, `supplier_name`, `supplier_phone`, `supplier_email`, `supplier_addres`) VALUES
(1, 'Berkah Nusantara', '021-4340194', 'support@berkahnusantara.co.id', 'Jl. Berkah'),
(4, 'MASPION', '084-9349-34', '', ''),
(5, 'PT. PANAROMA', '089-987-345', '', '\r\n\r\n'),
(6, 'PT. PALAWIJA', '031-234875', '', ''),
(7, '', '', 'GFGG', 'jhk');
