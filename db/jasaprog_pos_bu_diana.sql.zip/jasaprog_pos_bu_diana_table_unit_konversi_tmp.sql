
-- --------------------------------------------------------

--
-- Table structure for table `unit_konversi_tmp`
--

DROP TABLE IF EXISTS `unit_konversi_tmp`;
CREATE TABLE `unit_konversi_tmp` (
  `unit_konversi_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `unit_id` int(11) NOT NULL,
  `unit_jml` bigint(20) NOT NULL,
  `unit_konversi` int(255) NOT NULL,
  `unit_konversi_jml` bigint(20) NOT NULL,
  `harga_konversi` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `unit_konversi_tmp`
--

TRUNCATE TABLE `unit_konversi_tmp`;