
-- --------------------------------------------------------

--
-- Table structure for table `stock_retur_penjualan`
--

DROP TABLE IF EXISTS `stock_retur_penjualan`;
CREATE TABLE `stock_retur_penjualan` (
  `item_stock_retur_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `item_stock_qty` float NOT NULL,
  `branch_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `stock_retur_penjualan`
--

TRUNCATE TABLE `stock_retur_penjualan`;
--
-- Dumping data for table `stock_retur_penjualan`
--

INSERT INTO `stock_retur_penjualan` (`item_stock_retur_id`, `item_id`, `item_stock_qty`, `branch_id`) VALUES
(2, 1, 18, 3),
(3, 2, 1, 3);
