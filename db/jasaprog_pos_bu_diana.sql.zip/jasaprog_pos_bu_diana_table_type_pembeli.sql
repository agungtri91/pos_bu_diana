
-- --------------------------------------------------------

--
-- Table structure for table `type_pembeli`
--

DROP TABLE IF EXISTS `type_pembeli`;
CREATE TABLE `type_pembeli` (
  `type_id_pembeli` int(11) NOT NULL,
  `type_pembeli_name` varchar(200) NOT NULL,
  `diskon` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `tipe_diskon_berlaku` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `type_pembeli`
--

TRUNCATE TABLE `type_pembeli`;
--
-- Dumping data for table `type_pembeli`
--

INSERT INTO `type_pembeli` (`type_id_pembeli`, `type_pembeli_name`, `diskon`, `branch_id`, `tipe_diskon_berlaku`) VALUES
(14, 'Gold', 0, 3, 1),
(15, 'Silver', 0, 3, 0),
(16, 'SIlver 2', 0, 3, 0),
(17, '', 0, 3, 0);
