
-- --------------------------------------------------------

--
-- Table structure for table `office`
--

DROP TABLE IF EXISTS `office`;
CREATE TABLE `office` (
  `office_id` int(11) NOT NULL,
  `office_name` varchar(200) NOT NULL,
  `office_img` text NOT NULL,
  `office_desc` text NOT NULL,
  `office_address` text NOT NULL,
  `office_phone` varchar(100) NOT NULL,
  `office_email` varchar(300) NOT NULL,
  `office_city` varchar(100) NOT NULL,
  `office_owner` varchar(100) NOT NULL,
  `office_owner_phone` varchar(100) NOT NULL,
  `office_owner_address` varchar(100) NOT NULL,
  `office_owner_email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `office`
--

TRUNCATE TABLE `office`;
--
-- Dumping data for table `office`
--

INSERT INTO `office` (`office_id`, `office_name`, `office_img`, `office_desc`, `office_address`, `office_phone`, `office_email`, `office_city`, `office_owner`, `office_owner_phone`, `office_owner_address`, `office_owner_email`) VALUES
(1, 'Jasaweb', '1494183539_jasaweblogo.png', '', '									JL. RAYA LONTAR 226 SURABAYA																																																																								', '(031)-04408-0-02', '', 'SURABAYA', '', '0856-343-423', 'Surabaya', '');
