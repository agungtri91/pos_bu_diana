
-- --------------------------------------------------------

--
-- Table structure for table `kategori_utama`
--

DROP TABLE IF EXISTS `kategori_utama`;
CREATE TABLE `kategori_utama` (
  `id_kategori_utama` int(11) NOT NULL,
  `kategori_utama_name` varbinary(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `kategori_utama`
--

TRUNCATE TABLE `kategori_utama`;